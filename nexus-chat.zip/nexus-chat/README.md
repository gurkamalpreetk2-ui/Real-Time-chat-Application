# ⚡ Nexus Chat

> Production-grade AI-powered real-time chat — **WhatsApp + Discord + Telegram + ChatGPT** in one codebase.

## Stack

| Layer | Tech |
|---|---|
| Frontend | React 18 + Vite + Tailwind CSS + Framer Motion |
| State | Zustand |
| Backend | Express.js + Node.js (ESM) |
| Database | MongoDB + Mongoose |
| Real-time | Socket.io |
| AI | **Groq API** (LLaMA 3 70B — free tier available) |
| Auth | JWT + Refresh token rotation |

---

## Quick Start

### 1 — Install dependencies

```bash
cd nexus-chat
npm run install:all
```

### 2 — Configure the server

```bash
cd server
cp .env.example .env
```

Edit `.env` and fill in:

| Variable | Where to get it |
|---|---|
| `MONGO_URI` | Local MongoDB or [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) free tier |
| `JWT_SECRET` | Any random 32+ char string |
| `JWT_REFRESH_SECRET` | Another random 32+ char string |
| `GROQ_API_KEY` | **Free** at [console.groq.com](https://console.groq.com) — takes 30 seconds |

### 3 — Seed the database

```bash
cd server
node seed.js
```

This creates 6 demo users, direct chats, group chats, and an AI chat with example messages.

### 4 — Start the app

```bash
cd ..          # back to nexus-chat root
npm run dev    # starts server (5000) + client (5173) concurrently
```

Open **http://localhost:5173** and log in with any seed account:

```
alex@nexus.dev  / password123   ← admin, recommended
priya@nexus.dev / password123
jordan@nexus.dev / password123
```

---

## Features

- ✅ Real-time messaging with Socket.io
- ✅ **AI chat** powered by Groq LLaMA 3 (streaming SSE)
- ✅ Smart reply suggestions
- ✅ Delete for me / Delete for everyone
- ✅ Unsend messages (10 min window)
- ✅ Message reactions (emoji picker)
- ✅ Reply to messages
- ✅ Forward messages
- ✅ Typing indicators & read receipts
- ✅ Online / offline / away / busy status
- ✅ Last seen timestamps
- ✅ Group chats with admin permissions
- ✅ Dark / light mode (persistent)
- ✅ File + voice message support
- ✅ Glassmorphism UI with Framer Motion animations
- ✅ Mobile-responsive layout
- ✅ Dashboard with analytics

---

## Project Structure

```
nexus-chat/
├── server/
│   ├── controllers/      authController, chatController, messageController,
│   │                     aiController (Groq), userController, dashboardController
│   ├── models/           User, Chat, Message
│   ├── routes/           auth, chats, messages, ai, users, upload, dashboard
│   ├── middleware/       auth (JWT), errorHandler, validate
│   ├── socket/           Socket.io event handler
│   ├── seed.js           ← database seeder
│   └── index.js          ← entry point
│
└── client/src/
    ├── components/
    │   ├── chat/         ChatWindow, MessageList, MessageBubble, MessageInput
    │   ├── layout/       Sidebar, ChatListItem
    │   ├── modals/       DeleteMessage, DeleteChat, Forward, UserProfile,
    │   │                 CreateGroup, Settings
    │   └── ui/           UserAvatar, ModalBase
    ├── pages/            Login, Register, Chat, Dashboard, Profile
    ├── store/            authStore, chatStore, uiStore (Zustand)
    ├── services/         api.js (Axios + refresh interceptor), socket.js
    └── hooks/            useSocketEvents.js
```

---

## Groq API

Nexus Chat uses [Groq](https://groq.com) for AI — it's **free**, extremely fast (LPU inference), and requires no credit card.

1. Go to **https://console.groq.com**
2. Sign up (GitHub login works)
3. Create an API key
4. Paste it as `GROQ_API_KEY` in `server/.env`

Model used: `llama3-70b-8192` (fast, capable, 8 192 token context)
