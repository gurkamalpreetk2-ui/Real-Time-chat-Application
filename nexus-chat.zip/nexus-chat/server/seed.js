/**
 * Nexus Chat — Database Seeder
 * Usage:  node seed.js
 *
 * Drops all existing Users, Chats, Messages and repopulates with
 * realistic demo data so you can log in and see a working app immediately.
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, '.env') });

// ─── Inline schemas (avoid circular-dep issues with the real model files) ───

const userSchema = new mongoose.Schema(
  {
    name:          { type: String, required: true },
    email:         { type: String, required: true, unique: true, lowercase: true },
    password:      { type: String, required: true, select: false },
    avatar:        { type: String, default: '' },
    bio:           { type: String, default: '' },
    status:        { type: String, enum: ['online','offline','away','busy'], default: 'offline' },
    lastSeen:      { type: Date, default: Date.now },
    socketId:      { type: String, default: null },
    theme:         { type: String, default: 'dark' },
    notifications: { type: Boolean, default: true },
    blockedUsers:  [{ type: mongoose.Schema.Types.ObjectId }],
    pinnedChats:   [{ type: mongoose.Schema.Types.ObjectId }],
    archivedChats: [{ type: mongoose.Schema.Types.ObjectId }],
    mutedChats:    [{ type: mongoose.Schema.Types.ObjectId }],
    starredMessages:[{ type: mongoose.Schema.Types.ObjectId }],
    refreshTokens: [String],
    isVerified:    { type: Boolean, default: true },
    role:          { type: String, enum: ['user','admin'], default: 'user' },
  },
  { timestamps: true }
);

const chatSchema = new mongoose.Schema(
  {
    name:             { type: String, default: '' },
    isGroup:          { type: Boolean, default: false },
    isAIChat:         { type: Boolean, default: false },
    participants:     [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    groupAdmin:       { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    groupAvatar:      { type: String, default: '' },
    groupDescription: { type: String, default: '' },
    lastMessage:      { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
    unreadCounts:     { type: Map, of: Number, default: {} },
    admins:           [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

const messageSchema = new mongoose.Schema(
  {
    chat:               { type: mongoose.Schema.Types.ObjectId, ref: 'Chat', required: true },
    sender:             { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    content:            { type: String, default: '' },
    type:               { type: String, enum: ['text','image','video','audio','file','ai','system'], default: 'text' },
    attachments:        [],
    status:             { type: String, enum: ['sending','sent','delivered','read'], default: 'sent' },
    readBy:             [{ user: { type: mongoose.Schema.Types.ObjectId }, readAt: Date }],
    deliveredTo:        [{ user: { type: mongoose.Schema.Types.ObjectId }, deliveredAt: Date }],
    replyTo:            { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
    reactions:          [{ emoji: String, users: [{ type: mongoose.Schema.Types.ObjectId }] }],
    mentions:           [{ type: mongoose.Schema.Types.ObjectId }],
    deletedFor:         [{ type: mongoose.Schema.Types.ObjectId }],
    deletedForEveryone: { type: Boolean, default: false },
    unsent:             { type: Boolean, default: false },
    aiMetadata:         { model: String, tokensUsed: Number, processingTime: Number },
    edited:             { type: Boolean, default: false },
    pinned:             { type: Boolean, default: false },
  },
  { timestamps: true }
);

const User    = mongoose.model('User',    userSchema);
const Chat    = mongoose.model('Chat',    chatSchema);
const Message = mongoose.model('Message', messageSchema);

// ─── Seed data ───────────────────────────────────────────────────────────────

const USERS_DATA = [
  { name: 'Alex Morgan',  email: 'alex@nexus.dev',   password: 'password123', status: 'online',   role: 'admin',
    bio: 'Full-stack dev & coffee enthusiast ☕',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Alex' },
  { name: 'Priya Sharma', email: 'priya@nexus.dev',  password: 'password123', status: 'online',
    bio: 'UI/UX Designer · Making things beautiful ✨',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Priya' },
  { name: 'Jordan Lee',   email: 'jordan@nexus.dev', password: 'password123', status: 'away',
    bio: 'DevOps engineer, Linux nerd 🐧',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Jordan' },
  { name: 'Sofia Reyes',  email: 'sofia@nexus.dev',  password: 'password123', status: 'busy',
    bio: 'Product Manager · Building things people love 🚀',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Sofia' },
  { name: 'Kai Tanaka',   email: 'kai@nexus.dev',    password: 'password123', status: 'offline',
    bio: 'Backend wizard · Rust & Go enthusiast',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Kai',
    lastSeen: new Date(Date.now() - 2 * 3600_000) },
  { name: 'Maya Patel',   email: 'maya@nexus.dev',   password: 'password123', status: 'online',
    bio: 'Data scientist 📊 · ML/AI researcher',
    avatar: 'https://api.dicebear.com/8.x/avataaars/svg?seed=Maya' },
  // Internal AI bot — never used to log in
  { name: 'Nexus AI', email: 'ai@nexus-chat.internal', password: 'nexus-ai-internal-bot-secret-9x', status: 'online', role: 'admin',
    bio: 'Your intelligent AI assistant.',
    avatar: 'https://api.dicebear.com/8.x/bottts/svg?seed=NexusAI' },
];

// ─── Conversation templates ───────────────────────────────────────────────────
// minsAgo: how many minutes in the past the message was sent

const DIRECT = {
  'Alex-Priya': [
    { from: 'Alex Morgan',  text: 'Hey Priya! Are the new dashboard mockups ready?',                          minsAgo: 320 },
    { from: 'Priya Sharma', text: 'Almost! Just tweaking the color palette 🎨 Should be done in an hour',    minsAgo: 318 },
    { from: 'Alex Morgan',  text: 'The client is really excited about the glassmorphism style we pitched',    minsAgo: 315 },
    { from: 'Priya Sharma', text: 'Same! backdrop-blur looks stunning on dark backgrounds',                   minsAgo: 312 },
    { from: 'Alex Morgan',  text: 'Can you drop a preview here when ready?',                                  minsAgo: 310 },
    { from: 'Priya Sharma', text: 'Absolutely! Also adding light-mode variants this time 🌞',                 minsAgo: 308 },
    { from: 'Alex Morgan',  text: "Don't forget standup at 3pm 🕒",                                          minsAgo: 60  },
    { from: 'Priya Sharma', text: 'On my calendar! See you there 👋',                                        minsAgo: 58  },
  ],
  'Alex-Jordan': [
    { from: 'Jordan Lee',  text: 'Alex, staging is throwing 502s intermittently. Checking now',               minsAgo: 180 },
    { from: 'Alex Morgan', text: 'Oh no. Load balancer again?',                                               minsAgo: 178 },
    { from: 'Jordan Lee',  text: 'Yep. Nginx config got overwritten in the last deploy. Rolling back',        minsAgo: 175 },
    { from: 'Alex Morgan', text: "How?? I thought the deploy scripts were locked down",                       minsAgo: 173 },
    { from: 'Jordan Lee',  text: 'Someone pushed directly to main 😤 Adding branch protection now',           minsAgo: 170 },
    { from: 'Alex Morgan', text: 'Good call. Ping me when staging is back',                                   minsAgo: 168 },
    { from: 'Jordan Lee',  text: 'Back up ✅ Response times normal. Running smoke tests',                     minsAgo: 120 },
    { from: 'Alex Morgan', text: 'Legend 🙌 Thanks for the quick fix!',                                      minsAgo: 118 },
    { from: 'Jordan Lee',  text: 'All smoke tests passing. We\'re good 🚀',                                   minsAgo: 30  },
  ],
  'Alex-Sofia': [
    { from: 'Sofia Reyes', text: 'Hey Alex! Q4 roadmap doc is ready for review',                             minsAgo: 500 },
    { from: 'Alex Morgan', text: 'Great, dropping the link in the channel?',                                 minsAgo: 498 },
    { from: 'Sofia Reyes', text: 'Posted in #product. Main priorities: AI features, mobile, enterprise plan',minsAgo: 495 },
    { from: 'Alex Morgan', text: 'Smart reply suggestions were a huge hit in user testing 🎯',               minsAgo: 490 },
    { from: 'Sofia Reyes', text: 'Users spent 40% more time in app when smart replies were on 📊',           minsAgo: 488 },
    { from: 'Alex Morgan', text: "We should double down on that for sure",                                   minsAgo: 485 },
    { from: 'Sofia Reyes', text: 'Mobile beta target: end of Q4. React Native to reuse components',          minsAgo: 483 },
    { from: 'Alex Morgan', text: "Smart. Let's sync Thursday to go through the spec",                        minsAgo: 480 },
    { from: 'Sofia Reyes', text: 'Thursday 2pm works! Adding it to the calendar now 📅',                    minsAgo: 45  },
  ],
  'Priya-Kai': [
    { from: 'Priya Sharma', text: 'Kai, quick Q — what\'s the max file size for uploads?',                   minsAgo: 240 },
    { from: 'Kai Tanaka',   text: '10MB per file, 5 files max per request. Defined in multer middleware',    minsAgo: 238 },
    { from: 'Priya Sharma', text: 'Perfect! Designing the file picker and need the right constraints',       minsAgo: 235 },
    { from: 'Kai Tanaka',   text: 'Also: images get a thumbnail generated on upload via Cloudinary transform',minsAgo: 233 },
    { from: 'Priya Sharma', text: 'Oh nice! So I can show thumbnails without loading full images first?',    minsAgo: 230 },
    { from: 'Kai Tanaka',   text: 'Exactly. Thumbnail URL is in the attachment object alongside main URL',   minsAgo: 228 },
    { from: 'Priya Sharma', text: "You're the best Kai! 🙏",                                                 minsAgo: 226 },
    { from: 'Kai Tanaka',   text: 'Happy to help. Ping me if you need the schema details',                   minsAgo: 90  },
  ],
  'Maya-Sofia': [
    { from: 'Maya Patel',  text: 'Sofia! Sentiment model is done. 94.2% accuracy on test set 🎉',           minsAgo: 400 },
    { from: 'Sofia Reyes', text: "That's incredible! Way above the 90% target. How'd you get there?",       minsAgo: 398 },
    { from: 'Maya Patel',  text: 'Fine-tuned a smaller BERT variant on our chat data + augmentation tricks',minsAgo: 395 },
    { from: 'Sofia Reyes', text: 'Can we ship this in the next sprint? Mood-based insights would be huge',   minsAgo: 393 },
    { from: 'Maya Patel',  text: 'Already a FastAPI microservice! Just needs an API call from the backend', minsAgo: 390 },
    { from: 'Sofia Reyes', text: "Wow you were ahead of me 😄 Demo it in Friday's all-hands!",              minsAgo: 388 },
    { from: 'Maya Patel',  text: "Will prep a short demo. Got conversation-insight charts too",              minsAgo: 385 },
    { from: 'Sofia Reyes', text: 'This is going to blow the team away 🚀',                                  minsAgo: 20  },
  ],
};

const GROUPS = {
  'Engineering Team': [
    { from: 'Alex Morgan',  text: 'Morning team! Daily standup notes are in Notion 📝',                     minsAgo: 480 },
    { from: 'Jordan Lee',   text: 'Infra update: migrated DB to the new cluster last night. Zero downtime ✅',minsAgo: 478 },
    { from: 'Kai Tanaka',   text: 'Nice! p95 response times dropped 40ms after the migration',              minsAgo: 475 },
    { from: 'Jordan Lee',   text: 'Exactly the target. NVMe storage makes a big difference',                minsAgo: 473 },
    { from: 'Alex Morgan',  text: 'Kai, how\'s the WebSocket refactor?',                                    minsAgo: 470 },
    { from: 'Kai Tanaka',   text: 'Finished! Switching from polling to push for status updates. PR is up',  minsAgo: 468 },
    { from: 'Maya Patel',   text: 'Will review after standup! AI streaming averaging under 200ms TTFB 🚀',  minsAgo: 465 },
    { from: 'Alex Morgan',  text: 'Users are going to love that speed. Ship it!',                           minsAgo: 463 },
    { from: 'Jordan Lee',   text: 'Should we rate-limit the AI endpoint? It\'s compute-heavy',              minsAgo: 460 },
    { from: 'Kai Tanaka',   text: '10 req/min per user seems reasonable for now',                           minsAgo: 458 },
    { from: 'Alex Morgan',  text: "Agreed. Let's add that this sprint",                                     minsAgo: 455 },
    { from: 'Maya Patel',   text: "I'll handle it today. Will update the rate-limiter config",              minsAgo: 453 },
    { from: 'Jordan Lee',   text: 'Deploy pipeline is 2× faster with the new caching layer 🏎️',           minsAgo: 120 },
    { from: 'Alex Morgan',  text: 'This team is on fire 🔥 Amazing work everyone',                         minsAgo: 118 },
    { from: 'Kai Tanaka',   text: "Don't forget team lunch Friday! 🍜",                                     minsAgo: 30  },
    { from: 'Maya Patel',   text: 'Ramen please 🙏',                                                        minsAgo: 28  },
    { from: 'Jordan Lee',   text: '+1 for ramen',                                                           minsAgo: 25  },
    { from: 'Alex Morgan',  text: 'Ramen it is! 12:30 Friday ✅',                                          minsAgo: 10  },
  ],
  'Product & Design': [
    { from: 'Sofia Reyes',  text: 'User research done. Big themes: speed, AI features, mobile',             minsAgo: 600 },
    { from: 'Priya Sharma', text: 'Smart replies feedback was super consistent across all interviewees',    minsAgo: 598 },
    { from: 'Sofia Reyes',  text: 'NPS for AI chat was 72 — highest of any feature we\'ve tested 🎯',      minsAgo: 595 },
    { from: 'Alex Morgan',  text: 'That validates doubling down in Q4. Great data Sofia',                   minsAgo: 593 },
    { from: 'Priya Sharma', text: 'Working on a redesigned AI chat — more conversational, less transactional',minsAgo: 590},
    { from: 'Sofia Reyes',  text: 'Love the direction! Can we see early concepts before Thursday?',         minsAgo: 588 },
    { from: 'Priya Sharma', text: 'Figma link by Wednesday EOD 👌',                                        minsAgo: 585 },
    { from: 'Alex Morgan',  text: 'Should we add a dedicated AI tab in the sidebar?',                      minsAgo: 583 },
    { from: 'Sofia Reyes',  text: 'Unanimous user preference for that over buried in list',                 minsAgo: 580 },
    { from: 'Priya Sharma', text: 'Already mocking it! Glowing AI indicator + pinned position 💜',         minsAgo: 578 },
    { from: 'Alex Morgan',  text: 'You read minds Priya 😄',                                               minsAgo: 575 },
    { from: 'Sofia Reyes',  text: 'Mobile designs next. Tap targets need to be 48px min',                  minsAgo: 200 },
    { from: 'Priya Sharma', text: 'On it! Following Material guidelines throughout',                       minsAgo: 198 },
    { from: 'Sofia Reyes',  text: 'Figma components for mobile are up — check Mobile v2 page',             minsAgo: 15  },
    { from: 'Priya Sharma', text: 'Just opened it — these are gorgeous 😍',                                minsAgo: 12  },
  ],
  'All Hands': [
    { from: 'Sofia Reyes', text: '📢 All-hands Friday at 4pm! Q3 review + Q4 roadmap preview',            minsAgo: 1440 },
    { from: 'Alex Morgan', text: 'Thanks Sofia! Everyone please block their calendars',                    minsAgo: 1438 },
    { from: 'Jordan Lee',  text: 'Happy to demo the new cluster performance if there\'s a slot',           minsAgo: 1435 },
    { from: 'Sofia Reyes', text: 'Yes! Jordan: infra · Maya: AI/ML · Priya: design system',               minsAgo: 1433 },
    { from: 'Maya Patel',  text: 'Excited to share the 94% sentiment model results 🎯',                   minsAgo: 1430 },
    { from: 'Priya Sharma',text: 'New component library dark mode is chef\'s kiss 🤌',                     minsAgo: 1428 },
    { from: 'Kai Tanaka',  text: 'Will there be a recording for async viewing?',                           minsAgo: 1425 },
    { from: 'Sofia Reyes', text: 'Yes — recording + summary doc posted same day',                         minsAgo: 1423 },
    { from: 'Alex Morgan', text: 'Q3 numbers were strong. Really proud of what we shipped 🙌',            minsAgo: 1420 },
    { from: 'Sofia Reyes', text: 'Reminder: all-hands in 2 hours! Link in #general',                      minsAgo: 120  },
    { from: 'Alex Morgan', text: 'See everyone soon 👋',                                                   minsAgo: 118  },
  ],
};

const AI_CHAT = [
  { role: 'user', from: 'Alex Morgan',
    text: 'Can you explain how WebSockets differ from Server-Sent Events?', minsAgo: 200 },
  { role: 'ai',
    text: `Great question! Here's a concise breakdown:

## WebSockets vs SSE

### WebSockets
- **Bidirectional** — client and server can both send at any time
- Single persistent TCP connection after the HTTP upgrade
- Binary + text support
- Best for: real-time chat, multiplayer games, collaborative editing

\`\`\`js
const ws = new WebSocket('wss://api.example.com/ws');
ws.onmessage = (e) => console.log(e.data);
ws.send('Hello!');
\`\`\`

### Server-Sent Events (SSE)
- **Unidirectional** — server → client only
- Plain HTTP — works through proxies and firewalls
- Built-in auto-reconnect
- Best for: live feeds, notifications, **AI streaming** ✅

\`\`\`js
const es = new EventSource('/api/stream');
es.onmessage = (e) => console.log(e.data);
\`\`\`

### Quick decision table
| Use case | Best choice |
|---|---|
| AI text streaming | SSE |
| Chat app | WebSocket |
| Stock ticker | SSE |
| Multiplayer game | WebSocket |

Nexus Chat uses **WebSocket for chat** (bidirectional) and **SSE for AI responses** (one-way stream). Best of both worlds 🚀`,
    minsAgo: 199 },
  { role: 'user', from: 'Alex Morgan',
    text: "That makes sense! What's the best way to handle WebSocket reconnection in React?", minsAgo: 195 },
  { role: 'ai',
    text: `Here's a production-ready pattern using Socket.io:

\`\`\`js
// services/socket.js
import { io } from 'socket.io-client';

export const initSocket = (token) =>
  io(API_URL, {
    auth: { token },
    reconnection: true,
    reconnectionDelay: 1000,      // start at 1s
    reconnectionDelayMax: 30000,  // cap at 30s
    reconnectionAttempts: 10,
  });
\`\`\`

**Key points:**
1. Socket.io handles exponential backoff automatically
2. **Re-join rooms** after reconnect — sockets lose membership on disconnect
3. **Fetch missed messages** with \`GET /messages?since=<last_ts>\`
4. Show a subtle "Reconnecting…" banner in the UI

Socket.io does the hard work; your job is just syncing state after reconnect 💪`,
    minsAgo: 194 },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

const ago = (minutes) => new Date(Date.now() - minutes * 60_000);
const log   = (m) => console.log(`  \x1b[32m✅\x1b[0m ${m}`);
const info  = (m) => console.log(`  \x1b[36mℹ\x1b[0m  ${m}`);
const warn  = (m) => console.log(`  \x1b[33m⚠\x1b[0m  ${m}`);
const head  = (m) => console.log(`\n\x1b[35m${m}\x1b[0m`);

// ─── Main ─────────────────────────────────────────────────────────────────────

async function seed() {
  console.log('\n\x1b[35m╔══════════════════════════════════════╗\x1b[0m');
  console.log('\x1b[35m║     Nexus Chat — Database Seeder     ║\x1b[0m');
  console.log('\x1b[35m╚══════════════════════════════════════╝\x1b[0m');

  const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/nexus-chat';
  info(`Connecting to MongoDB: ${uri}`);
  await mongoose.connect(uri);
  log('Connected to MongoDB');

  // ── Wipe ─────────────────────────────────────────────────────────────────
  head('🗑  Clearing existing data…');
  const [u, c, m] = await Promise.all([
    User.deleteMany({}),
    Chat.deleteMany({}),
    Message.deleteMany({}),
  ]);
  log(`Deleted ${u.deletedCount} users, ${c.deletedCount} chats, ${m.deletedCount} messages`);

  // ── Users ─────────────────────────────────────────────────────────────────
  head('👥 Creating users…');
  const userMap = {};
  for (const u of USERS_DATA) {
    const hashed = await bcrypt.hash(u.password || 'password123', 12);
    const user = await User.create({ ...u, password: hashed });
    userMap[u.name] = user;
    log(`${user.name} <${user.email}>`);
  }

  const alex   = userMap['Alex Morgan'];
  const priya  = userMap['Priya Sharma'];
  const jordan = userMap['Jordan Lee'];
  const sofia  = userMap['Sofia Reyes'];
  const kai    = userMap['Kai Tanaka'];
  const maya   = userMap['Maya Patel'];
  const aiBot  = userMap['Nexus AI'];

  // ── Direct chats ──────────────────────────────────────────────────────────
  head('💬 Creating direct chats…');
  const DIRECT_MAP = [
    { pair: [alex, priya],  key: 'Alex-Priya'  },
    { pair: [alex, jordan], key: 'Alex-Jordan' },
    { pair: [alex, sofia],  key: 'Alex-Sofia'  },
    { pair: [priya, kai],   key: 'Priya-Kai'   },
    { pair: [maya, sofia],  key: 'Maya-Sofia'  },
  ];
  const directChats = {};
  for (const { pair, key } of DIRECT_MAP) {
    const chat = await Chat.create({
      isGroup: false,
      participants: [pair[0]._id, pair[1]._id],
    });
    directChats[key] = { chat, pair };
    log(`${pair[0].name} ↔ ${pair[1].name}`);
  }

  // ── Group chats ───────────────────────────────────────────────────────────
  head('👥 Creating group chats…');
  const engChat = await Chat.create({
    name: 'Engineering Team', isGroup: true,
    participants: [alex._id, jordan._id, kai._id, maya._id],
    groupAdmin: alex._id, admins: [alex._id],
    groupDescription: 'Engineering discussions, deploys, and war stories 🔧',
  }); log('Engineering Team');

  const productChat = await Chat.create({
    name: 'Product & Design', isGroup: true,
    participants: [alex._id, priya._id, sofia._id],
    groupAdmin: sofia._id, admins: [sofia._id],
    groupDescription: 'Product roadmap, design reviews, and user research 🎨',
  }); log('Product & Design');

  const allHandsChat = await Chat.create({
    name: 'All Hands', isGroup: true,
    participants: [alex._id, priya._id, jordan._id, sofia._id, kai._id, maya._id],
    groupAdmin: alex._id, admins: [alex._id, sofia._id],
    groupDescription: 'Company-wide announcements 📢',
  }); log('All Hands');

  // ── AI chat ───────────────────────────────────────────────────────────────
  head('🤖 Creating AI chat…');
  const aiChat = await Chat.create({
    name: 'Nexus AI', isAIChat: true,
    participants: [alex._id, aiBot._id],
  }); log(`AI chat for ${alex.name}`);

  // ── Messages helper ───────────────────────────────────────────────────────
  async function seedMessages(chat, messages) {
    let last = null;
    for (const m of messages) {
      const sender = userMap[m.from] || aiBot;
      const ts = ago(m.minsAgo);
      const otherParts = chat.participants.filter((p) => p.toString() !== sender._id.toString());
      last = await Message.create({
        chat:    chat._id,
        sender:  sender._id,
        content: m.text,
        type:    m.type || 'text',
        status:  'read',
        readBy:  otherParts.map((p) => ({ user: p, readAt: ts })),
        createdAt: ts, updatedAt: ts,
      });
    }
    if (last) await Chat.findByIdAndUpdate(chat._id, { lastMessage: last._id });
    return last;
  }

  // ── Seed direct messages ──────────────────────────────────────────────────
  head('📨 Seeding messages…');
  for (const [key, { chat, pair }] of Object.entries(directChats)) {
    const msgs = DIRECT[key];
    if (!msgs) continue;
    await seedMessages(chat, msgs);
    log(`${pair[0].name} ↔ ${pair[1].name} (${msgs.length} messages)`);
  }

  // Reactions on Alex-Priya chat
  const apMessages = await Message.find({ chat: directChats['Alex-Priya'].chat._id }).sort({ createdAt: 1 });
  if (apMessages.length >= 4) {
    await Message.findByIdAndUpdate(apMessages[1]._id, {
      reactions: [{ emoji: '❤️', users: [alex._id] }, { emoji: '🔥', users: [priya._id] }],
    });
    await Message.findByIdAndUpdate(apMessages[3]._id, {
      reactions: [{ emoji: '👍', users: [priya._id, alex._id] }],
    });
    log('Added reactions to Alex-Priya chat');
  }

  // Pin a message in Alex-Jordan chat
  const ajMessages = await Message.find({ chat: directChats['Alex-Jordan'].chat._id }).sort({ createdAt: -1 });
  if (ajMessages[0]) {
    await Message.findByIdAndUpdate(ajMessages[0]._id, {
      pinned: true, pinnedBy: alex._id, pinnedAt: new Date(),
    });
    log('Pinned latest message in Alex-Jordan chat');
  }

  // ── Seed group messages ───────────────────────────────────────────────────
  const groupMap = { 'Engineering Team': engChat, 'Product & Design': productChat, 'All Hands': allHandsChat };
  for (const [name, chat] of Object.entries(groupMap)) {
    const msgs = GROUPS[name];
    if (!msgs) continue;
    await seedMessages(chat, msgs);
    log(`Group "${name}" (${msgs.length} messages)`);
  }

  // ── Seed AI chat ──────────────────────────────────────────────────────────
  head('🤖 Seeding AI conversation…');
  let lastAI = null;
  for (const m of AI_CHAT) {
    const sender = m.role === 'user' ? alex : aiBot;
    const ts = ago(m.minsAgo);
    lastAI = await Message.create({
      chat:    aiChat._id,
      sender:  sender._id,
      content: m.text,
      type:    m.role === 'ai' ? 'ai' : 'text',
      status:  'read',
      readBy:  [{ user: alex._id, readAt: ts }],
      ...(m.role === 'ai' && {
        aiMetadata: {
          model: 'llama3-70b-8192',
          tokensUsed: Math.ceil(m.text.length / 4),
          processingTime: 800 + Math.floor(Math.random() * 700),
        },
      }),
      createdAt: ts, updatedAt: ts,
    });
  }
  if (lastAI) await Chat.findByIdAndUpdate(aiChat._id, { lastMessage: lastAI._id });
  log(`AI chat seeded (${AI_CHAT.length} messages)`);

  // ── Extras ────────────────────────────────────────────────────────────────
  head('⭐ Applying extras…');

  // Pin Engineering Team chat for Alex
  await User.findByIdAndUpdate(alex._id, { pinnedChats: [engChat._id] });
  log('Pinned "Engineering Team" for Alex');

  // Star a couple of messages for Alex
  const toStar = await Message.find({ chat: engChat._id }).limit(2);
  if (toStar.length) {
    await User.findByIdAndUpdate(alex._id, { starredMessages: toStar.map((m) => m._id) });
    log(`Starred ${toStar.length} messages for Alex`);
  }

  // ── Summary ───────────────────────────────────────────────────────────────
  const [uc, cc, mc] = await Promise.all([
    User.countDocuments(),
    Chat.countDocuments(),
    Message.countDocuments(),
  ]);

  console.log(`
\x1b[35m╔══════════════════════════════════════╗\x1b[0m
\x1b[35m║       ✅  Seeding complete!           ║\x1b[0m
\x1b[35m╚══════════════════════════════════════╝\x1b[0m

  \x1b[32m📊 Database totals\x1b[0m
  ─────────────────────────────────────
  Users    : ${uc}  (including 1 AI bot)
  Chats    : ${cc}  (${DIRECT_MAP.length} direct · 3 groups · 1 AI)
  Messages : ${mc}

  \x1b[32m🔑 Login credentials\x1b[0m
  ─────────────────────────────────────
  alex@nexus.dev    / password123  (admin)
  priya@nexus.dev   / password123
  jordan@nexus.dev  / password123
  sofia@nexus.dev   / password123
  kai@nexus.dev     / password123
  maya@nexus.dev    / password123

  \x1b[32m🚀 Start the app\x1b[0m
  ─────────────────────────────────────
  cd nexus-chat && npm run dev
  → http://localhost:5173
`);

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error('\n\x1b[31m❌ Seed failed:\x1b[0m', err.message);
  console.error(err.stack);
  mongoose.disconnect().finally(() => process.exit(1));
});
