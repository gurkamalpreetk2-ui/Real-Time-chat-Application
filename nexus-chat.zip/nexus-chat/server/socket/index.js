import jwt from 'jsonwebtoken';
import User from '../models/User.js';

// Map: userId -> Set of socketIds
const userSockets = new Map();
// Map: socketId -> userId
const socketUsers = new Map();
// Map: userId -> typing { chatId, timeout }
const typingUsers = new Map();

export const initializeSocket = (io) => {
  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
      if (!token) return next(new Error('Authentication required'));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id).select('-password -refreshTokens');
      if (!user) return next(new Error('User not found'));

      socket.userId = user._id.toString();
      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.userId;
    console.log(`🔌 User connected: ${socket.user.name} (${socket.id})`);

    // Track socket
    if (!userSockets.has(userId)) userSockets.set(userId, new Set());
    userSockets.get(userId).add(socket.id);
    socketUsers.set(socket.id, userId);

    // Update user status to online
    await User.findByIdAndUpdate(userId, { status: 'online', socketId: socket.id });
    
    // Broadcast online status
    socket.broadcast.emit('user:status', { userId, status: 'online' });

    // Join all user's chat rooms
   const { default: Chat } = await import('../models/Chat.js');
    const chats = await Chat.find({ participants: userId });
    chats.forEach((chat) => socket.join(chat._id.toString()));

    // Personal room for direct notifications
    socket.join(`user:${userId}`);

    // ====== TYPING EVENTS ======
    socket.on('typing:start', ({ chatId }) => {
      // Clear existing timeout
      const existing = typingUsers.get(`${userId}:${chatId}`);
      if (existing) clearTimeout(existing);

      socket.to(chatId).emit('typing:update', {
        chatId,
        userId,
        userName: socket.user.name,
        isTyping: true,
      });

      // Auto-stop after 3 seconds
      const timeout = setTimeout(() => {
        socket.to(chatId).emit('typing:update', {
          chatId,
          userId,
          isTyping: false,
        });
        typingUsers.delete(`${userId}:${chatId}`);
      }, 3000);

      typingUsers.set(`${userId}:${chatId}`, timeout);
    });

    socket.on('typing:stop', ({ chatId }) => {
      const existing = typingUsers.get(`${userId}:${chatId}`);
      if (existing) clearTimeout(existing);
      typingUsers.delete(`${userId}:${chatId}`);

      socket.to(chatId).emit('typing:update', {
        chatId,
        userId,
        isTyping: false,
      });
    });

    // ====== MESSAGE EVENTS ======
    socket.on('message:delivered', async ({ messageId }) => {
      try {
        const { Message } = await import('../models/Message.js');
        const message = await Message.findByIdAndUpdate(
          messageId,
          {
            $addToSet: { deliveredTo: { user: userId, deliveredAt: new Date() } },
            $set: { status: 'delivered' },
          },
          { new: true }
        );

        if (message) {
          socket.to(message.chat.toString()).emit('message:statusUpdate', {
            messageId,
            status: 'delivered',
            userId,
          });
        }
      } catch (err) {
        console.error('Delivery tracking error:', err);
      }
    });

    socket.on('message:read', async ({ chatId, messageIds }) => {
      try {
        const { Message } = await import('../models/Message.js');
        await Message.updateMany(
          { _id: { $in: messageIds }, 'readBy.user': { $ne: userId } },
          {
            $addToSet: { readBy: { user: userId, readAt: new Date() } },
            $set: { status: 'read' },
          }
        );

        socket.to(chatId).emit('messages:read', { chatId, userId, messageIds });
      } catch (err) {
        console.error('Read receipt error:', err);
      }
    });

    // ====== CHAT ROOM MANAGEMENT ======
    socket.on('chat:join', async ({ chatId }) => {
      const chat = await Chat.findOne({ _id: chatId, participants: userId });
      if (chat) {
        socket.join(chatId);
        socket.emit('chat:joined', { chatId });
      }
    });

    socket.on('chat:leave', ({ chatId }) => {
      socket.leave(chatId);
    });

    // ====== USER ACTIVITY ======
    socket.on('user:away', async () => {
      await User.findByIdAndUpdate(userId, { status: 'away' });
      socket.broadcast.emit('user:status', { userId, status: 'away' });
    });

    socket.on('user:active', async () => {
      await User.findByIdAndUpdate(userId, { status: 'online' });
      socket.broadcast.emit('user:status', { userId, status: 'online' });
    });

    // ====== CALL SIGNALING (WebRTC) ======
    socket.on('call:offer', ({ targetUserId, offer, callType }) => {
      const targetSockets = userSockets.get(targetUserId);
      if (targetSockets) {
        targetSockets.forEach((sid) => {
          io.to(sid).emit('call:incoming', {
            callerId: userId,
            callerName: socket.user.name,
            callerAvatar: socket.user.avatar,
            offer,
            callType,
          });
        });
      }
    });

    socket.on('call:answer', ({ callerId, answer }) => {
      const callerSockets = userSockets.get(callerId);
      if (callerSockets) {
        callerSockets.forEach((sid) => {
          io.to(sid).emit('call:answered', { answer, answererId: userId });
        });
      }
    });

    socket.on('call:ice-candidate', ({ targetUserId, candidate }) => {
      const targetSockets = userSockets.get(targetUserId);
      if (targetSockets) {
        targetSockets.forEach((sid) => {
          io.to(sid).emit('call:ice-candidate', { candidate, fromUserId: userId });
        });
      }
    });

    socket.on('call:end', ({ targetUserId }) => {
      const targetSockets = userSockets.get(targetUserId);
      if (targetSockets) {
        targetSockets.forEach((sid) => {
          io.to(sid).emit('call:ended', { byUserId: userId });
        });
      }
    });

    // ====== DISCONNECT ======
    socket.on('disconnect', async () => {
      console.log(`🔌 User disconnected: ${socket.user.name}`);

      // Remove socket tracking
      userSockets.get(userId)?.delete(socket.id);
      if (userSockets.get(userId)?.size === 0) {
        userSockets.delete(userId);
      }
      socketUsers.delete(socket.id);

      // Clear all typing indicators
      typingUsers.forEach((timeout, key) => {
        if (key.startsWith(`${userId}:`)) {
          clearTimeout(timeout);
          typingUsers.delete(key);
        }
      });

      // Only set offline if no other sockets for this user
      if (!userSockets.has(userId)) {
        await User.findByIdAndUpdate(userId, {
          status: 'offline',
          lastSeen: new Date(),
          socketId: null,
        });
        socket.broadcast.emit('user:status', {
          userId,
          status: 'offline',
          lastSeen: new Date(),
        });
      }
    });
  });

  console.log('🔌 Socket.io initialized');
};

export const getOnlineUsers = () => Array.from(userSockets.keys());
export const isUserOnline = (userId) => userSockets.has(userId);
