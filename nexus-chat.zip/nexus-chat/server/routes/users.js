import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { searchUsers, getUserProfile, updateProfile, blockUser, getOnlineUsers, updateStatus } from '../controllers/userController.js';

const router = Router();
router.use(protect);

router.get('/search', searchUsers);
router.get('/online', getOnlineUsers);
router.get('/:id', getUserProfile);
router.put('/profile', updateProfile);
router.put('/status', updateStatus);
router.put('/block/:id', blockUser);

export default router;
