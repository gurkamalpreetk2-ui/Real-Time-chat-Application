import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { streamAIResponse, summarizeConversation, translateMessage, suggestReplies, detectSentiment } from '../controllers/aiController.js';

const router = Router();
router.use(protect);

router.post('/chat', streamAIResponse);
router.post('/summarize', summarizeConversation);
router.post('/translate', translateMessage);
router.post('/suggest-replies', suggestReplies);
router.post('/sentiment', detectSentiment);

export default router;
