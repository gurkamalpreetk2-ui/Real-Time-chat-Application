import { Router } from 'express';
import { protect, isAdmin } from '../middleware/auth.js';
import { getDashboardStats } from '../controllers/dashboardController.js';

const router = Router();
router.use(protect);

router.get('/stats', getDashboardStats);

export default router;
