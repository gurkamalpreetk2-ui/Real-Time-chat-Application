import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { getChats, createOrGetDirectChat, createGroupChat, getOrCreateAIChat, archiveChat, pinChat, muteChat, deleteChat, updateGroup, addMember } from '../controllers/chatController.js';

const router = Router();
router.use(protect);

router.get('/', getChats);
router.post('/direct', createOrGetDirectChat);
router.post('/group', createGroupChat);
router.get('/ai', getOrCreateAIChat);
router.put('/:id/archive', archiveChat);
router.put('/:id/pin', pinChat);
router.put('/:id/mute', muteChat);
router.put('/:id/group', updateGroup);
router.put('/:id/add-member', addMember);
router.delete('/:id', deleteChat);

export default router;
