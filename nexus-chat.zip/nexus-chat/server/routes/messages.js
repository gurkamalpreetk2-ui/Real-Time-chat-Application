import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { getMessages, sendMessage, deleteForMe, deleteForEveryone, unsendMessage, reactToMessage, pinMessage, starMessage, editMessage, searchMessages } from '../controllers/messageController.js';

const router = Router();
router.use(protect);

router.get('/:chatId', getMessages);
router.get('/:chatId/search', searchMessages);
router.post('/', sendMessage);
router.delete('/:id/for-me', deleteForMe);
router.delete('/:id/for-everyone', deleteForEveryone);
router.put('/:id/unsend', unsendMessage);
router.put('/:id/react', reactToMessage);
router.put('/:id/pin', pinMessage);
router.put('/:id/star', starMessage);
router.put('/:id/edit', editMessage);

export default router;
