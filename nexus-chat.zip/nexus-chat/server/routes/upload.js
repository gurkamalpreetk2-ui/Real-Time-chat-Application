import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import multer from 'multer';
import path from 'path';

const router = Router();
router.use(protect);

const ALLOWED_TYPES = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp',
  'application/pdf',
  'video/mp4', 'video/webm',
  'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain',
];

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${file.mimetype} is not allowed`), false);
    }
  },
});

const getFileType = (mimetype) => {
  if (mimetype.startsWith('image/')) return 'image';
  if (mimetype.startsWith('video/')) return 'video';
  if (mimetype.startsWith('audio/')) return 'audio';
  return 'document';
};

router.post('/', upload.array('files', 5), async (req, res, next) => {
  try {
    if (!req.files?.length) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    // In production: upload to Cloudinary / S3.
    // For dev we return placeholder URLs so the rest of the app works.
    const files = req.files.map((file) => ({
      url: `https://placehold.co/400x300?text=${encodeURIComponent(file.originalname)}`,
      name: file.originalname,
      size: file.size,
      mimeType: file.mimetype,
      type: getFileType(file.mimetype),
    }));

    res.json({ files });
  } catch (err) {
    next(err);
  }
});

export default router;
