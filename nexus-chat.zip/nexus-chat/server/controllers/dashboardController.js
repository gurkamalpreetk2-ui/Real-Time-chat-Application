import User from '../models/User.js';
import Message from '../models/Message.js';
import Chat from '../models/Chat.js';
import { AppError } from '../middleware/errorHandler.js';

// @GET /api/dashboard/stats
export const getDashboardStats = async (req, res, next) => {
  try {
    const now = new Date();
    const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [
      totalUsers,
      onlineUsers,
      totalMessages,
      totalChats,
      aiMessages,
      recentActivity,
    ] = await Promise.all([
      User.countDocuments({ email: { $ne: 'ai@nexus-chat.internal' } }),
      User.countDocuments({ status: 'online', email: { $ne: 'ai@nexus-chat.internal' } }),
      Message.countDocuments(),
      Chat.countDocuments(),
      Message.countDocuments({ type: 'ai' }),
      Message.aggregate([
        { $match: { createdAt: { $gte: last7Days } } },
        {
          $group: {
            _id: {
              $dateToString: { format: '%Y-%m-%d', date: '$createdAt' },
            },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
    ]);

    // Fill in missing days
    const activityMap = {};
    recentActivity.forEach((item) => { activityMap[item._id] = item.count; });

    const dailyActivity = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = date.toISOString().split('T')[0];
      dailyActivity.push({
        date: dateStr,
        label: date.toLocaleDateString('en-US', { weekday: 'short' }),
        count: activityMap[dateStr] || 0,
      });
    }

    res.json({
      stats: {
        totalUsers,
        onlineUsers,
        totalMessages,
        totalChats,
        aiMessages,
        aiUsagePercent: totalMessages > 0 ? Math.round((aiMessages / totalMessages) * 100) : 0,
      },
      dailyActivity,
    });
  } catch (err) {
    next(err);
  }
};
