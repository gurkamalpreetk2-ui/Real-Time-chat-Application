import User from '../models/User.js';
import { AppError } from '../middleware/errorHandler.js';

// @GET /api/users/search
export const searchUsers = async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 1) return res.json({ users: [] });

    const users = await User.find({
      _id: { $ne: req.user._id },
      blockedUsers: { $ne: req.user._id },
      $or: [
        { name: { $regex: q, $options: 'i' } },
        { email: { $regex: q, $options: 'i' } },
      ],
    })
      .select('name email avatar status lastSeen bio')
      .limit(20);

    res.json({ users });
  } catch (err) {
    next(err);
  }
};

// @GET /api/users/:id
export const getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('-password -refreshTokens -blockedUsers');
    if (!user) throw new AppError('User not found', 404);
    res.json({ user });
  } catch (err) {
    next(err);
  }
};

// @PUT /api/users/profile
export const updateProfile = async (req, res, next) => {
  try {
    const { name, bio, avatar, theme, notifications } = req.body;

    const updated = await User.findByIdAndUpdate(
      req.user._id,
      {
        $set: {
          ...(name && { name }),
          ...(bio !== undefined && { bio }),
          ...(avatar && { avatar }),
          ...(theme && { theme }),
          ...(notifications !== undefined && { notifications }),
        },
      },
      { new: true, runValidators: true }
    );

    res.json({ user: updated });
  } catch (err) {
    next(err);
  }
};

// @PUT /api/users/block/:id
export const blockUser = async (req, res, next) => {
  try {
    const targetId = req.params.id;
    const isBlocked = req.user.blockedUsers?.includes(targetId);

    const update = isBlocked
      ? { $pull: { blockedUsers: targetId } }
      : { $addToSet: { blockedUsers: targetId } };

    await User.findByIdAndUpdate(req.user._id, update);
    res.json({ blocked: !isBlocked, userId: targetId });
  } catch (err) {
    next(err);
  }
};

// @GET /api/users/online
export const getOnlineUsers = async (req, res, next) => {
  try {
    const users = await User.find({
      status: 'online',
      _id: { $ne: req.user._id },
    }).select('name avatar status lastSeen');

    res.json({ users });
  } catch (err) {
    next(err);
  }
};

// @PUT /api/users/status
export const updateStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const validStatuses = ['online', 'offline', 'away', 'busy'];
    if (!validStatuses.includes(status)) throw new AppError('Invalid status', 400);

    await User.findByIdAndUpdate(req.user._id, {
      $set: { status, ...(status === 'offline' && { lastSeen: new Date() }) },
    });

    res.json({ status });
  } catch (err) {
    next(err);
  }
};
