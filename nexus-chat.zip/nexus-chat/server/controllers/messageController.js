import Message from '../models/Message.js';
import Chat from '../models/Chat.js';
import User from '../models/User.js';
import { AppError } from '../middleware/errorHandler.js';

// GET /api/messages/:chatId
export const getMessages = async (req, res, next) => {
  try {
    const { chatId } = req.params;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 50));

    const chat = await Chat.findOne({ _id: chatId, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found or access denied', 404);

    const query = {
      chat: chatId,
      deletedFor: { $ne: req.user._id },
    };

    const total = await Message.countDocuments(query);

    const messages = await Message.find(query)
      .populate('sender', 'name avatar status')
      .populate({
        path: 'replyTo',
        select: 'content sender type',
        populate: { path: 'sender', select: 'name' },
      })
      .populate('mentions', 'name avatar')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    // Mark as read — fire and forget, don't block response
    const myIdStr = req.user._id.toString();
    const unreadIds = messages
      .filter((m) => m.sender?._id?.toString() !== myIdStr && !m.readBy?.some((r) => r.user?.toString() === myIdStr))
      .map((m) => m._id);

    if (unreadIds.length) {
      Message.updateMany(
        { _id: { $in: unreadIds } },
        { $addToSet: { readBy: { user: req.user._id, readAt: new Date() } }, $set: { status: 'read' } }
      ).catch(() => {});

      Chat.findByIdAndUpdate(chatId, { $set: { [`unreadCounts.${req.user._id}`]: 0 } }).catch(() => {});

      req.io.to(chatId).emit('messages:read', {
        chatId,
        userId: req.user._id,
        messageIds: unreadIds,
      });
    }

    res.json({
      messages: messages.reverse(),
      pagination: { page, limit, total, hasMore: total > page * limit },
    });
  } catch (err) {
    next(err);
  }
};

// POST /api/messages
export const sendMessage = async (req, res, next) => {
  try {
    const { chatId, content, type = 'text', replyTo, mentions, attachments } = req.body;

    if (!chatId) throw new AppError('chatId is required', 400);
    if (!content?.trim() && !attachments?.length) throw new AppError('Message content or attachment is required', 400);

    const chat = await Chat.findOne({ _id: chatId, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found or access denied', 404);

    const message = await Message.create({
      chat: chatId,
      sender: req.user._id,
      content: content?.trim() || '',
      type,
      replyTo: replyTo || undefined,
      mentions: mentions || [],
      attachments: attachments || [],
      status: 'sent',
    });

    await message.populate([
      { path: 'sender', select: 'name avatar status' },
      {
        path: 'replyTo',
        select: 'content sender type',
        populate: { path: 'sender', select: 'name' },
      },
      { path: 'mentions', select: 'name avatar' },
    ]);

    // Update chat
    const updateData = { lastMessage: message._id };
    chat.participants.forEach((pid) => {
      if (pid.toString() !== req.user._id.toString()) {
        const curr = chat.unreadCounts?.get(pid.toString()) || 0;
        updateData[`unreadCounts.${pid}`] = curr + 1;
      }
    });
    await Chat.findByIdAndUpdate(chatId, { $set: updateData });

    req.io.to(chatId).emit('message:new', message);
    req.io.to(chatId).emit('chat:updated', { chatId, lastMessage: message });

    res.status(201).json({ message });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/messages/:id/for-me
export const deleteForMe = async (req, res, next) => {
  try {
    const message = await Message.findOne({ _id: req.params.id });
    if (!message) throw new AppError('Message not found', 404);

    await Message.findByIdAndUpdate(req.params.id, {
      $addToSet: { deletedFor: req.user._id },
    });

    res.json({ message: 'Message deleted for you' });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/messages/:id/for-everyone
export const deleteForEveryone = async (req, res, next) => {
  try {
    const message = await Message.findById(req.params.id);
    if (!message) throw new AppError('Message not found', 404);

    if (message.sender.toString() !== req.user._id.toString()) {
      throw new AppError('You can only delete your own messages for everyone', 403);
    }

    await Message.findByIdAndUpdate(req.params.id, {
      $set: { deletedForEveryone: true, content: '', attachments: [] },
    });

    req.io.to(message.chat.toString()).emit('message:deletedForEveryone', {
      messageId: req.params.id,
      chatId: message.chat,
    });

    res.json({ message: 'Message deleted for everyone' });
  } catch (err) {
    next(err);
  }
};

// PUT /api/messages/:id/unsend
export const unsendMessage = async (req, res, next) => {
  try {
    const message = await Message.findById(req.params.id);
    if (!message) throw new AppError('Message not found', 404);

    if (message.sender.toString() !== req.user._id.toString()) {
      throw new AppError('You can only unsend your own messages', 403);
    }

    const tenMinsAgo = new Date(Date.now() - 10 * 60 * 1000);
    if (message.createdAt < tenMinsAgo) {
      throw new AppError('Cannot unsend messages older than 10 minutes', 400);
    }

    await Message.findByIdAndUpdate(req.params.id, {
      $set: { unsent: true, content: 'This message was removed', attachments: [] },
    });

    req.io.to(message.chat.toString()).emit('message:unsent', {
      messageId: req.params.id,
      chatId: message.chat,
    });

    res.json({ message: 'Message unsent' });
  } catch (err) {
    next(err);
  }
};

// PUT /api/messages/:id/react
export const reactToMessage = async (req, res, next) => {
  try {
    const { emoji } = req.body;
    if (!emoji) throw new AppError('emoji is required', 400);

    const message = await Message.findById(req.params.id);
    if (!message) throw new AppError('Message not found', 404);

    const userId = req.user._id.toString();
    const existing = message.reactions.find((r) => r.emoji === emoji);

    if (existing) {
      const idx = existing.users.findIndex((u) => u.toString() === userId);
      if (idx > -1) {
        existing.users.splice(idx, 1);
        if (existing.users.length === 0) {
          message.reactions = message.reactions.filter((r) => r.emoji !== emoji);
        }
      } else {
        existing.users.push(req.user._id);
      }
    } else {
      message.reactions.push({ emoji, users: [req.user._id] });
    }

    await message.save();

    req.io.to(message.chat.toString()).emit('message:reaction', {
      messageId: req.params.id,
      reactions: message.reactions,
    });

    res.json({ reactions: message.reactions });
  } catch (err) {
    next(err);
  }
};

// PUT /api/messages/:id/pin
export const pinMessage = async (req, res, next) => {
  try {
    const message = await Message.findById(req.params.id);
    if (!message) throw new AppError('Message not found', 404);

    const updated = await Message.findByIdAndUpdate(
      req.params.id,
      { $set: { pinned: !message.pinned, pinnedBy: req.user._id, pinnedAt: new Date() } },
      { new: true }
    );

    req.io.to(message.chat.toString()).emit('message:pinned', {
      messageId: req.params.id,
      pinned: updated.pinned,
    });

    res.json({ pinned: updated.pinned });
  } catch (err) {
    next(err);
  }
};

// PUT /api/messages/:id/star
export const starMessage = async (req, res, next) => {
  try {
    const messageId = req.params.id;
    const user = await User.findById(req.user._id);
    const isStarred = user.starredMessages?.some((id) => id.toString() === messageId);

    await User.findByIdAndUpdate(req.user._id, isStarred
      ? { $pull: { starredMessages: messageId } }
      : { $addToSet: { starredMessages: messageId } }
    );

    res.json({ starred: !isStarred });
  } catch (err) {
    next(err);
  }
};

// PUT /api/messages/:id/edit
export const editMessage = async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content?.trim()) throw new AppError('Content is required', 400);

    const message = await Message.findById(req.params.id);
    if (!message) throw new AppError('Message not found', 404);

    if (message.sender.toString() !== req.user._id.toString()) {
      throw new AppError('You can only edit your own messages', 403);
    }

    message.editHistory = [
      ...(message.editHistory || []),
      { content: message.content, editedAt: new Date() },
    ];
    message.content = content.trim();
    message.edited = true;
    message.editedAt = new Date();
    await message.save();

    req.io.to(message.chat.toString()).emit('message:edited', {
      messageId: req.params.id,
      content: message.content,
      edited: true,
    });

    res.json({ message });
  } catch (err) {
    next(err);
  }
};

// GET /api/messages/:chatId/search
export const searchMessages = async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q?.trim()) return res.json({ messages: [] });

    const chat = await Chat.findOne({ _id: req.params.chatId, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found', 404);

    const messages = await Message.find({
      chat: req.params.chatId,
      content: { $regex: q.trim(), $options: 'i' },
      deletedFor: { $ne: req.user._id },
      deletedForEveryone: { $ne: true },
    })
      .populate('sender', 'name avatar')
      .sort({ createdAt: -1 })
      .limit(20);

    res.json({ messages });
  } catch (err) {
    next(err);
  }
};
