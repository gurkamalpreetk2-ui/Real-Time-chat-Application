import Groq from 'groq-sdk';
import Message from '../models/Message.js';
import Chat from '../models/Chat.js';
import User from '../models/User.js';
import { AppError } from '../middleware/errorHandler.js';

// Groq client - lazy init so missing key gives a clean error at request time
let groqClient = null;
const getGroq = () => {
  if (!groqClient) {
    if (!process.env.GROQ_API_KEY) throw new AppError('GROQ_API_KEY is not configured', 500);
    groqClient = new Groq({ apiKey: process.env.GROQ_API_KEY });
  }
  return groqClient;
};

const AI_MODEL = 'llama3-70b-8192'; // fast, free Groq model

const AI_SYSTEM_PROMPT = `You are Nexus AI, a helpful, intelligent, and friendly AI assistant integrated into the Nexus Chat platform. You are knowledgeable, concise, and engaging.

Format your responses using markdown when appropriate:
- **bold** and *italic* for emphasis
- \`inline code\` and fenced code blocks with language identifiers
- Bullet lists and numbered lists
- Tables for comparisons
- Emojis to keep responses lively 🚀

Keep responses helpful and appropriately concise. For code questions always provide working, runnable examples.`;

// ── POST /api/ai/chat  (streaming SSE) ──────────────────────────────────────
export const streamAIResponse = async (req, res, next) => {
  try {
    const { chatId, message, conversationHistory = [] } = req.body;

    if (!message?.trim()) throw new AppError('Message is required', 400);

    const chat = await Chat.findOne({ _id: chatId, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found', 404);

    // AI only responds to online users
    const currentUser = await User.findById(req.user._id).select('status');
    if (currentUser?.status === 'offline') {
      return res.status(400).json({ error: 'AI only responds when you are online' });
    }

    // ── SSE headers ──────────────────────────────────────────────────────────
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    // Build messages array for Groq
    const groqMessages = [
      ...conversationHistory
        .slice(-10)
        .filter((m) => m.content && m.content.trim())
        .map((m) => ({
          role: m.sender?.toString() === req.user._id.toString() ? 'user' : 'assistant',
          content: m.content,
        })),
      { role: 'user', content: message.trim() },
    ];

    const startTime = Date.now();
    let fullContent = '';

    const stream = await getGroq().chat.completions.create({
      model: AI_MODEL,
      max_tokens: 2048,
      temperature: 0.7,
      stream: true,
      messages: [
        { role: 'system', content: AI_SYSTEM_PROMPT },
        ...groqMessages,
      ],
    });

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content;
      if (delta) {
        fullContent += delta;
        res.write(`data: ${JSON.stringify({ type: 'delta', text: delta })}\n\n`);
      }
    }

    const processingTime = Date.now() - startTime;

    // Save AI message to DB
    const aiUser = await User.findOne({ email: 'ai@nexus-chat.internal' });
    if (aiUser && fullContent.trim()) {
      const aiMessage = await Message.create({
        chat: chatId,
        sender: aiUser._id,
        content: fullContent,
        type: 'ai',
        status: 'read',
        aiMetadata: {
          model: AI_MODEL,
          tokensUsed: Math.ceil(fullContent.length / 4),
          processingTime,
        },
      });

      await aiMessage.populate('sender', 'name avatar status');
      await Chat.findByIdAndUpdate(chatId, { lastMessage: aiMessage._id });
      req.io.to(chatId).emit('message:new', aiMessage);

      res.write(`data: ${JSON.stringify({ type: 'done', messageId: aiMessage._id })}\n\n`);
    } else {
      res.write(`data: ${JSON.stringify({ type: 'done', messageId: null })}\n\n`);
    }

    res.end();
  } catch (err) {
    if (!res.headersSent) {
      next(err);
    } else {
      res.write(`data: ${JSON.stringify({ type: 'error', error: err.message })}\n\n`);
      res.end();
    }
  }
};

// ── POST /api/ai/summarize ────────────────────────────────────────────────────
export const summarizeConversation = async (req, res, next) => {
  try {
    const { chatId } = req.body;
    if (!chatId) throw new AppError('chatId is required', 400);

    const chat = await Chat.findOne({ _id: chatId, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found', 404);

    const messages = await Message.find({
      chat: chatId,
      deletedForEveryone: { $ne: true },
      unsent: { $ne: true },
      content: { $ne: '' },
    })
      .populate('sender', 'name')
      .sort({ createdAt: -1 })
      .limit(50);

    if (!messages.length) return res.json({ summary: 'No messages to summarize yet.' });

    const conversationText = messages
      .reverse()
      .map((m) => `${m.sender?.name || 'User'}: ${m.content}`)
      .join('\n');

    const response = await getGroq().chat.completions.create({
      model: AI_MODEL,
      max_tokens: 300,
      messages: [
        { role: 'system', content: 'You are a concise summarizer. Return a 2-3 sentence summary.' },
        { role: 'user', content: `Summarize this conversation:\n\n${conversationText}` },
      ],
    });

    res.json({ summary: response.choices[0]?.message?.content || 'Unable to summarize.' });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/ai/translate ────────────────────────────────────────────────────
export const translateMessage = async (req, res, next) => {
  try {
    const { text, targetLanguage = 'English' } = req.body;
    if (!text?.trim()) throw new AppError('text is required', 400);

    const response = await getGroq().chat.completions.create({
      model: AI_MODEL,
      max_tokens: 500,
      messages: [
        { role: 'system', content: 'You are a translator. Return ONLY the translated text, nothing else.' },
        { role: 'user', content: `Translate to ${targetLanguage}: ${text}` },
      ],
    });

    res.json({
      translation: response.choices[0]?.message?.content?.trim() || text,
      targetLanguage,
    });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/ai/suggest-replies ──────────────────────────────────────────────
export const suggestReplies = async (req, res, next) => {
  try {
    const { messages: recentMessages } = req.body;
    if (!Array.isArray(recentMessages) || !recentMessages.length) {
      return res.json({ suggestions: [] });
    }

    const context = recentMessages
      .slice(-5)
      .filter((m) => m.content)
      .map((m) => `${m.senderName || 'User'}: ${m.content}`)
      .join('\n');

    const response = await getGroq().chat.completions.create({
      model: AI_MODEL,
      max_tokens: 150,
      temperature: 0.8,
      messages: [
        {
          role: 'system',
          content: 'You suggest short reply options. Respond ONLY with a valid JSON array of 3 strings, each max 10 words. No markdown, no explanation.',
        },
        { role: 'user', content: `Suggest replies for:\n${context}` },
      ],
    });

    let suggestions = ['Sure!', 'Got it!', 'Thanks!'];
    try {
      const raw = response.choices[0]?.message?.content?.trim() || '';
      const match = raw.match(/\[[\s\S]*\]/);
      if (match) suggestions = JSON.parse(match[0]).slice(0, 3);
    } catch { /* fall back to defaults */ }

    res.json({ suggestions });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/ai/sentiment ────────────────────────────────────────────────────
export const detectSentiment = async (req, res, next) => {
  try {
    const { text } = req.body;
    if (!text?.trim()) return res.json({ sentiment: 'neutral', score: 0.5, emoji: '😐' });

    const response = await getGroq().chat.completions.create({
      model: AI_MODEL,
      max_tokens: 60,
      messages: [
        {
          role: 'system',
          content: 'Return ONLY valid JSON: {"sentiment":"positive|negative|neutral","score":0.0-1.0,"emoji":"<emoji>"}',
        },
        { role: 'user', content: `Sentiment of: "${text.slice(0, 200)}"` },
      ],
    });

    let result = { sentiment: 'neutral', score: 0.5, emoji: '😐' };
    try {
      const match = response.choices[0]?.message?.content?.match(/\{[\s\S]*\}/);
      if (match) result = { ...result, ...JSON.parse(match[0]) };
    } catch { /* use defaults */ }

    res.json(result);
  } catch (err) {
    next(err);
  }
};
