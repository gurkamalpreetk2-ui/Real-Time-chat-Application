import Chat from '../models/Chat.js';
import Message from '../models/Message.js';
import User from '../models/User.js';
import { AppError } from '../middleware/errorHandler.js';

const CHAT_POPULATE = [
  { path: 'participants', select: 'name avatar status lastSeen' },
  { path: 'lastMessage', populate: { path: 'sender', select: 'name' } },
  { path: 'groupAdmin', select: 'name avatar' },
];

// GET /api/chats
export const getChats = async (req, res, next) => {
  try {
    const currentUser = await User.findById(req.user._id).select('archivedChats');
    const archivedIds = currentUser?.archivedChats || [];

    const chats = await Chat.find({
      participants: req.user._id,
      _id: { $nin: archivedIds },
    })
      .populate(CHAT_POPULATE)
      .sort({ updatedAt: -1 });

    const chatsWithMeta = chats.map((chat) => {
      const obj = chat.toObject();
      obj.unreadCount = chat.unreadCounts?.get?.(req.user._id.toString()) || 0;
      return obj;
    });

    res.json({ chats: chatsWithMeta });
  } catch (err) {
    next(err);
  }
};

// POST /api/chats/direct
export const createOrGetDirectChat = async (req, res, next) => {
  try {
    const { userId } = req.body;
    if (!userId) throw new AppError('userId is required', 400);
    if (userId === req.user._id.toString()) throw new AppError('Cannot chat with yourself', 400);

    const targetUser = await User.findById(userId);
    if (!targetUser) throw new AppError('User not found', 404);

    if (req.user.blockedUsers?.includes(userId)) {
      throw new AppError('Cannot message a blocked user', 403);
    }

    // Find existing direct chat
    let chat = await Chat.findOne({
      isGroup: false,
      isAIChat: false,
      participants: { $all: [req.user._id, userId], $size: 2 },
    }).populate(CHAT_POPULATE);

    if (!chat) {
      chat = await Chat.create({
        isGroup: false,
        participants: [req.user._id, userId],
      });
      await chat.populate(CHAT_POPULATE);
    }

    res.json({ chat });
  } catch (err) {
    next(err);
  }
};

// POST /api/chats/group
export const createGroupChat = async (req, res, next) => {
  try {
    const { name, participants, description } = req.body;
    if (!name?.trim()) throw new AppError('Group name is required', 400);
    if (!Array.isArray(participants) || participants.length < 2) {
      throw new AppError('Group needs at least 2 other participants', 400);
    }

    const allParticipants = [...new Set([...participants, req.user._id.toString()])];

    const chat = await Chat.create({
      name: name.trim(),
      isGroup: true,
      participants: allParticipants,
      groupAdmin: req.user._id,
      admins: [req.user._id],
      groupDescription: description?.trim() || '',
    });

    await chat.populate(CHAT_POPULATE);

    // Notify all participants
    allParticipants.forEach((pid) => {
      req.io.to(`user:${pid}`).emit('chat:new', chat);
    });

    res.status(201).json({ chat });
  } catch (err) {
    next(err);
  }
};

// GET /api/chats/ai
export const getOrCreateAIChat = async (req, res, next) => {
  try {
    let aiUser = await User.findOne({ email: 'ai@nexus-chat.internal' });

    if (!aiUser) {
      const bcrypt = await import('bcryptjs');
      const hashed = await bcrypt.default.hash(`ai-secret-${Date.now()}`, 12);
      aiUser = await User.create({
        name: 'Nexus AI',
        email: 'ai@nexus-chat.internal',
        password: hashed,
        avatar: '',
        role: 'admin',
        status: 'online',
        isVerified: true,
      });
    }

    let chat = await Chat.findOne({
      isAIChat: true,
      participants: { $all: [req.user._id, aiUser._id] },
    }).populate('participants', 'name avatar status');

    if (!chat) {
      chat = await Chat.create({
        isAIChat: true,
        name: 'Nexus AI',
        participants: [req.user._id, aiUser._id],
      });
      await chat.populate('participants', 'name avatar status');
    }

    res.json({ chat });
  } catch (err) {
    next(err);
  }
};

// PUT /api/chats/:id/archive
export const archiveChat = async (req, res, next) => {
  try {
    const { id: chatId } = req.params;
    const user = await User.findById(req.user._id).select('archivedChats');
    const isArchived = user.archivedChats?.some((c) => c.toString() === chatId);

    await User.findByIdAndUpdate(req.user._id, isArchived
      ? { $pull: { archivedChats: chatId } }
      : { $addToSet: { archivedChats: chatId } }
    );

    res.json({ archived: !isArchived });
  } catch (err) {
    next(err);
  }
};

// PUT /api/chats/:id/pin
export const pinChat = async (req, res, next) => {
  try {
    const { id: chatId } = req.params;
    const user = await User.findById(req.user._id).select('pinnedChats');
    const isPinned = user.pinnedChats?.some((c) => c.toString() === chatId);

    await User.findByIdAndUpdate(req.user._id, isPinned
      ? { $pull: { pinnedChats: chatId } }
      : { $addToSet: { pinnedChats: chatId } }
    );

    res.json({ pinned: !isPinned });
  } catch (err) {
    next(err);
  }
};

// PUT /api/chats/:id/mute
export const muteChat = async (req, res, next) => {
  try {
    const { id: chatId } = req.params;
    const user = await User.findById(req.user._id).select('mutedChats');
    const isMuted = user.mutedChats?.some((c) => c.toString() === chatId);

    await User.findByIdAndUpdate(req.user._id, isMuted
      ? { $pull: { mutedChats: chatId } }
      : { $addToSet: { mutedChats: chatId } }
    );

    res.json({ muted: !isMuted });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/chats/:id
export const deleteChat = async (req, res, next) => {
  try {
    const chat = await Chat.findOne({ _id: req.params.id, participants: req.user._id });
    if (!chat) throw new AppError('Chat not found', 404);

    if (chat.isGroup && chat.groupAdmin?.toString() !== req.user._id.toString()) {
      throw new AppError('Only group admin can delete the group', 403);
    }

    await Message.deleteMany({ chat: req.params.id });
    await Chat.findByIdAndDelete(req.params.id);

    req.io.to(req.params.id).emit('chat:deleted', { chatId: req.params.id });

    res.json({ message: 'Chat deleted successfully' });
  } catch (err) {
    next(err);
  }
};

// PUT /api/chats/:id/group
export const updateGroup = async (req, res, next) => {
  try {
    const { name, description, avatar } = req.body;
    const chat = await Chat.findById(req.params.id);
    if (!chat?.isGroup) throw new AppError('Group not found', 404);

    const isAdmin = chat.admins?.some((a) => a.toString() === req.user._id.toString());
    if (!isAdmin) throw new AppError('Only admins can update group', 403);

    const updated = await Chat.findByIdAndUpdate(
      req.params.id,
      { $set: { ...(name && { name: name.trim() }), ...(description !== undefined && { groupDescription: description }), ...(avatar && { groupAvatar: avatar }) } },
      { new: true }
    ).populate(CHAT_POPULATE);

    req.io.to(req.params.id).emit('chat:groupUpdated', updated);
    res.json({ chat: updated });
  } catch (err) {
    next(err);
  }
};

// PUT /api/chats/:id/add-member
export const addMember = async (req, res, next) => {
  try {
    const { userId } = req.body;
    if (!userId) throw new AppError('userId is required', 400);

    const chat = await Chat.findById(req.params.id);
    if (!chat?.isGroup) throw new AppError('Group not found', 404);

    const isAdmin = chat.admins?.some((a) => a.toString() === req.user._id.toString());
    if (!isAdmin) throw new AppError('Only admins can add members', 403);

    const alreadyIn = chat.participants.some((p) => p.toString() === userId);
    if (alreadyIn) throw new AppError('User already in group', 400);

    await Chat.findByIdAndUpdate(req.params.id, { $addToSet: { participants: userId } });
    const updated = await Chat.findById(req.params.id).populate(CHAT_POPULATE);

    req.io.to(req.params.id).emit('chat:memberAdded', { chatId: req.params.id, userId });
    req.io.to(`user:${userId}`).emit('chat:new', updated);

    res.json({ chat: updated });
  } catch (err) {
    next(err);
  }
};
