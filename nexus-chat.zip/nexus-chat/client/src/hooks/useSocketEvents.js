import { useEffect } from 'react';
import { getSocket } from '../services/socket';
import { useChatStore } from '../store/chatStore';

export const useSocketEvents = () => {
  const {
    addMessage, updateMessage,
    handleMessageDeleted, handleMessageUnsent,
    setTyping, setUserStatus,
    addChat, removeChat,
  } = useChatStore();

  useEffect(() => {
    // Socket might not exist yet on first render — poll briefly
    let attempts = 0;
    let socket = getSocket();

    const attach = (s) => {
      s.on('message:new', addMessage);

      s.on('message:edited', ({ messageId, content, edited }) => {
        updateMessage(messageId, { content, edited });
      });

      s.on('message:deletedForEveryone', ({ messageId, chatId }) => {
        handleMessageDeleted(messageId, chatId);
      });

      s.on('message:unsent', ({ messageId, chatId }) => {
        handleMessageUnsent(messageId, chatId);
      });

      s.on('message:reaction', ({ messageId, reactions }) => {
        updateMessage(messageId, { reactions });
      });

      s.on('message:statusUpdate', ({ messageId, status }) => {
        updateMessage(messageId, { status });
      });

      s.on('messages:read', ({ messageIds }) => {
        messageIds?.forEach?.((id) => updateMessage(id, { status: 'read' }));
      });

      s.on('message:pinned', ({ messageId, pinned }) => {
        updateMessage(messageId, { pinned });
      });

      s.on('typing:update', ({ chatId, userId, userName, isTyping }) => {
        setTyping(chatId, userId, userName || 'User', isTyping);
      });

      s.on('user:status', ({ userId, status, lastSeen }) => {
        setUserStatus(userId, status, lastSeen);
      });

      s.on('chat:new', addChat);

      s.on('chat:deleted', ({ chatId }) => removeChat(chatId));
    };

    if (socket) {
      attach(socket);
    } else {
      // Retry up to 20 times (2 seconds)
      const interval = setInterval(() => {
        attempts++;
        socket = getSocket();
        if (socket) {
          clearInterval(interval);
          attach(socket);
        }
        if (attempts > 20) clearInterval(interval);
      }, 100);
    }

    return () => {
      const s = getSocket();
      if (!s) return;
      s.off('message:new');
      s.off('message:edited');
      s.off('message:deletedForEveryone');
      s.off('message:unsent');
      s.off('message:reaction');
      s.off('message:statusUpdate');
      s.off('messages:read');
      s.off('message:pinned');
      s.off('typing:update');
      s.off('user:status');
      s.off('chat:new');
      s.off('chat:deleted');
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
};
