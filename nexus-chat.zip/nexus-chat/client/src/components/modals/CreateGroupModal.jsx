import { useState } from 'react';
import { Users, Search, X, Check } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';
import { useChatStore } from '../../store/chatStore';
import ModalBase from '../ui/ModalBase';
import UserAvatar from '../ui/UserAvatar';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function CreateGroupModal() {
  const { closeModal } = useUIStore();
  const { addChat, setActiveChat } = useChatStore();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selected, setSelected] = useState([]);
  const [creating, setCreating] = useState(false);

  const onClose = () => closeModal('createGroup');

  const handleSearch = async (q) => {
    setSearch(q);
    if (!q.trim()) { setSearchResults([]); return; }
    try {
      const { data } = await api.get(`/users/search?q=${encodeURIComponent(q)}`);
      setSearchResults(data.users);
    } catch {}
  };

  const toggleUser = (u) => {
    setSelected((s) => s.find((x) => x._id === u._id) ? s.filter((x) => x._id !== u._id) : [...s, u]);
  };

  const handleCreate = async () => {
    if (!name.trim()) return toast.error('Group name required');
    if (selected.length < 2) return toast.error('Add at least 2 members');
    setCreating(true);
    try {
      const { data } = await api.post('/chats/group', {
        name: name.trim(),
        description,
        participants: selected.map((u) => u._id),
      });
      addChat(data.chat);
      setActiveChat(data.chat);
      toast.success('Group created!');
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create group');
    }
    setCreating(false);
  };

  return (
    <ModalBase title="Create Group" onClose={onClose} size="md">
      <div className="p-4 space-y-4">
        {/* Group name */}
        <div>
          <label className="text-xs text-nexus-muted mb-1.5 block">Group name *</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Project Team, Friends..."
            className="input-nexus w-full text-sm"
          />
        </div>

        {/* Description */}
        <div>
          <label className="text-xs text-nexus-muted mb-1.5 block">Description (optional)</label>
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What's this group about?"
            className="input-nexus w-full text-sm"
          />
        </div>

        {/* Search members */}
        <div>
          <label className="text-xs text-nexus-muted mb-1.5 block">Add members *</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-nexus-muted" />
            <input
              value={search}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search users..."
              className="input-nexus w-full pl-9 text-sm"
            />
          </div>
        </div>

        {/* Selected users */}
        {selected.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {selected.map((u) => (
              <div key={u._id} className="flex items-center gap-1.5 bg-nexus-accent/15 border border-nexus-accent/30 rounded-full px-2.5 py-1">
                <span className="text-xs">{u.name}</span>
                <button onClick={() => toggleUser(u)}>
                  <X className="w-3 h-3 text-nexus-muted hover:text-nexus-error" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Search results */}
        {searchResults.length > 0 && (
          <div className="max-h-40 overflow-y-auto space-y-1 bg-nexus-card rounded-xl p-2">
            {searchResults.map((u) => {
              const isSelected = selected.find((x) => x._id === u._id);
              return (
                <button key={u._id} onClick={() => toggleUser(u)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${isSelected ? 'bg-nexus-accent/15' : 'hover:bg-nexus-border/50'}`}>
                  <UserAvatar user={u} size="sm" />
                  <span className="text-sm flex-1 text-left">{u.name}</span>
                  {isSelected && <Check className="w-4 h-4 text-nexus-accent" />}
                </button>
              );
            })}
          </div>
        )}

        <div className="flex gap-2 justify-end pt-2">
          <button onClick={onClose} className="px-4 py-2 text-sm rounded-xl border border-nexus-border hover:bg-nexus-border/50 transition-colors">Cancel</button>
          <button onClick={handleCreate} disabled={creating} className="btn-nexus flex items-center gap-2">
            {creating ? <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Users className="w-3.5 h-3.5" />}
            Create Group
          </button>
        </div>
      </div>
    </ModalBase>
  );
}
