import { useState } from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';
import { useChatStore } from '../../store/chatStore';
import ModalBase from '../ui/ModalBase';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function DeleteChatModal() {
  const { modals, closeModal } = useUIStore();
  const { removeChat } = useChatStore();
  const chat = modals.deleteChat;
  const [deleting, setDeleting] = useState(false);

  const onClose = () => closeModal('deleteChat');

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await api.delete(`/chats/${chat._id}`);
      removeChat(chat._id);
      toast.success('Chat deleted');
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to delete chat');
    }
    setDeleting(false);
  };

  return (
    <ModalBase title="Delete chat" onClose={onClose}>
      <div className="p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-nexus-error/20 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-nexus-error" />
          </div>
          <div>
            <p className="text-sm">Delete <strong>{chat?.name || 'this chat'}</strong>?</p>
            <p className="text-xs text-nexus-muted mt-0.5">All messages will be permanently deleted.</p>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm rounded-xl border border-nexus-border hover:bg-nexus-border/50 transition-colors">Cancel</button>
          <button onClick={handleDelete} disabled={deleting} className="px-4 py-2 text-sm rounded-xl bg-nexus-error hover:bg-red-600 text-white transition-colors flex items-center gap-2">
            {deleting ? <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            Delete
          </button>
        </div>
      </div>
    </ModalBase>
  );
}
