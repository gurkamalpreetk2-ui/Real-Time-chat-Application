import { useUIStore } from '../../store/uiStore';
import { useAuthStore } from '../../store/authStore';
import { useChatStore } from '../../store/chatStore';
import ModalBase from '../ui/ModalBase';
import UserAvatar from '../ui/UserAvatar';
import { MessageSquare, UserX, Flag } from 'lucide-react';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function UserProfileModal() {
  const { modals, closeModal } = useUIStore();
  const { addChat, setActiveChat } = useChatStore();
  const user = modals.userProfile;
  const onClose = () => closeModal('userProfile');

  if (!user || !user._id) return null;

  const startChat = async () => {
    try {
      const { data } = await api.post('/chats/direct', { userId: user._id });
      addChat(data.chat);
      setActiveChat(data.chat);
      onClose();
    } catch { toast.error('Failed to start chat'); }
  };

  const handleBlock = async () => {
    try {
      await api.put(`/users/block/${user._id}`);
      toast.success('User blocked');
      onClose();
    } catch { toast.error('Failed'); }
  };

  return (
    <ModalBase onClose={onClose}>
      <div className="p-6 text-center">
        <UserAvatar user={user} size="2xl" className="mx-auto mb-4" showStatus />
        <h3 className="text-xl font-semibold">{user.name}</h3>
        <p className="text-nexus-muted text-sm mt-0.5">{user.email}</p>
        {user.bio && <p className="text-sm text-nexus-muted mt-3 bg-nexus-card rounded-xl px-4 py-2">{user.bio}</p>}
        <div className="flex items-center justify-center gap-1 mt-3">
          <div className={`w-2 h-2 rounded-full ${user.status === 'online' ? 'bg-nexus-online' : 'bg-nexus-offline'}`} />
          <span className="text-xs text-nexus-muted capitalize">{user.status || 'offline'}</span>
        </div>
        <div className="flex gap-2 mt-5">
          <button onClick={startChat} className="btn-nexus flex-1 flex items-center justify-center gap-2">
            <MessageSquare className="w-4 h-4" /> Message
          </button>
          <button onClick={handleBlock} className="px-3 py-2 rounded-xl border border-nexus-border hover:bg-nexus-error/10 hover:border-nexus-error/50 text-nexus-error transition-colors">
            <UserX className="w-4 h-4" />
          </button>
        </div>
      </div>
    </ModalBase>
  );
}
