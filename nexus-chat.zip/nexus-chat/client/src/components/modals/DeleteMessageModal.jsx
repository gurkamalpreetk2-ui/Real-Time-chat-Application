import { useState, useEffect } from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';
import { useChatStore } from '../../store/chatStore';
import ModalBase from '../ui/ModalBase';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function DeleteMessageModal() {
  const { modals, closeModal } = useUIStore();
  const { updateMessage, handleMessageDeleted } = useChatStore();
  const { message, type } = modals.deleteMessage || {};
  const [deleting, setDeleting] = useState(false);

  const onClose = () => closeModal('deleteMessage');

  const handleDelete = async () => {
    setDeleting(true);
    try {
      if (type === 'everyone') {
        await api.delete(`/messages/${message._id}/for-everyone`);
        handleMessageDeleted(message._id, message.chat?._id || message.chat);
        toast.success('Message deleted for everyone');
      } else {
        await api.delete(`/messages/${message._id}/for-me`);
        updateMessage(message._id, { deletedFor: [message._id] });
        toast.success('Message deleted for you');
      }
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed');
    }
    setDeleting(false);
  };

  return (
    <ModalBase title="Delete message" onClose={onClose}>
      <div className="p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-nexus-error/20 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-nexus-error" />
          </div>
          <div>
            <p className="text-sm text-nexus-text">
              {type === 'everyone'
                ? 'This message will be deleted for everyone in this chat.'
                : 'This message will be deleted only for you.'}
            </p>
            <p className="text-xs text-nexus-muted mt-0.5">This action cannot be undone.</p>
          </div>
        </div>

        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="px-4 py-2 text-sm rounded-xl border border-nexus-border hover:bg-nexus-border/50 transition-colors">
            Cancel
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="px-4 py-2 text-sm rounded-xl bg-nexus-error hover:bg-red-600 text-white transition-colors flex items-center gap-2"
          >
            {deleting ? <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
            Delete
          </button>
        </div>
      </div>
    </ModalBase>
  );
}
