import { useState, useEffect } from 'react';
import { Forward } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';
import { useChatStore } from '../../store/chatStore';
import ModalBase from '../ui/ModalBase';
import UserAvatar from '../ui/UserAvatar';
import { useAuthStore } from '../../store/authStore';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function ForwardMessageModal() {
  const { modals, closeModal } = useUIStore();
  const { chats } = useChatStore();
  const { user } = useAuthStore();
  const message = modals.forwardMessage;
  const [selected, setSelected] = useState([]);
  const [forwarding, setForwarding] = useState(false);

  const onClose = () => closeModal('forwardMessage');

  const toggle = (chatId) => {
    setSelected((s) => s.includes(chatId) ? s.filter((id) => id !== chatId) : [...s, chatId]);
  };

  const handleForward = async () => {
    if (!selected.length) return toast.error('Select at least one chat');
    setForwarding(true);
    try {
      await Promise.all(selected.map((chatId) =>
        api.post('/messages', { chatId, content: message.content, type: message.type, forwardedFrom: message._id })
      ));
      toast.success(`Forwarded to ${selected.length} chat${selected.length > 1 ? 's' : ''}`);
      onClose();
    } catch { toast.error('Forward failed'); }
    setForwarding(false);
  };

  const getDisplayName = (chat) => {
    if (chat.isGroup) return chat.name;
    const other = chat.participants?.find((p) => p._id !== user?._id);
    return other?.name || 'Chat';
  };

  return (
    <ModalBase title="Forward message" onClose={onClose} size="md">
      <div className="p-4">
        <p className="text-xs text-nexus-muted mb-3">Select chats to forward to:</p>
        <div className="space-y-1 max-h-64 overflow-y-auto">
          {chats.map((chat) => (
            <button key={chat._id} onClick={() => toggle(chat._id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors ${selected.includes(chat._id) ? 'bg-nexus-accent/15 border border-nexus-accent/30' : 'hover:bg-nexus-card'}`}>
              <UserAvatar user={chat.isGroup ? { name: chat.name, avatar: chat.groupAvatar } : chat.participants?.find((p) => p._id !== user?._id)} size="sm" />
              <span className="text-sm">{getDisplayName(chat)}</span>
              {selected.includes(chat._id) && <div className="ml-auto w-4 h-4 rounded-full bg-nexus-accent flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full" /></div>}
            </button>
          ))}
        </div>
        <div className="flex gap-2 justify-end mt-4">
          <button onClick={onClose} className="px-4 py-2 text-sm rounded-xl border border-nexus-border hover:bg-nexus-border/50 transition-colors">Cancel</button>
          <button onClick={handleForward} disabled={forwarding || !selected.length} className="btn-nexus flex items-center gap-2">
            {forwarding ? <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Forward className="w-3.5 h-3.5" />}
            Forward {selected.length > 0 && `(${selected.length})`}
          </button>
        </div>
      </div>
    </ModalBase>
  );
}
