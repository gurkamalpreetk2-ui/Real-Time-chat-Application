import { useState } from 'react';
import { Moon, Sun, Bell, BellOff, User, Lock, Palette, Save } from 'lucide-react';
import { useUIStore } from '../../store/uiStore';
import { useAuthStore } from '../../store/authStore';
import ModalBase from '../ui/ModalBase';
import UserAvatar from '../ui/UserAvatar';
import api from '../../services/api';
import toast from 'react-hot-toast';

const tabs = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'notifications', label: 'Notifications', icon: Bell },
];

export default function SettingsModal() {
  const { closeModal, theme, setTheme } = useUIStore();
  const { user, updateUser } = useAuthStore();
  const [activeTab, setActiveTab] = useState('profile');
  const [form, setForm] = useState({ name: user?.name || '', bio: user?.bio || '' });
  const [saving, setSaving] = useState(false);

  const onClose = () => closeModal('settings');

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const { data } = await api.put('/users/profile', form);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch { toast.error('Failed to save'); }
    setSaving(false);
  };

  const handleNotifToggle = async () => {
    try {
      const { data } = await api.put('/users/profile', { notifications: !user?.notifications });
      updateUser(data.user);
      toast.success(data.user.notifications ? 'Notifications enabled' : 'Notifications muted');
    } catch { toast.error('Failed'); }
  };

  return (
    <ModalBase title="Settings" onClose={onClose} size="md">
      <div className="flex h-80">
        {/* Tab sidebar */}
        <div className="w-36 border-r border-nexus-border p-2 space-y-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors ${activeTab === id ? 'bg-nexus-accent/15 text-nexus-accent-light' : 'text-nexus-muted hover:text-nexus-text hover:bg-nexus-border/50'}`}>
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 p-4 overflow-y-auto">
          {activeTab === 'profile' && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <UserAvatar user={user} size="lg" />
                <div>
                  <p className="text-sm font-medium">{user?.name}</p>
                  <p className="text-xs text-nexus-muted">{user?.email}</p>
                </div>
              </div>
              <div>
                <label className="text-xs text-nexus-muted block mb-1.5">Display name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="input-nexus w-full text-sm" />
              </div>
              <div>
                <label className="text-xs text-nexus-muted block mb-1.5">Bio</label>
                <textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })}
                  placeholder="Tell people about yourself..."
                  rows={3} className="input-nexus w-full text-sm resize-none" maxLength={200} />
                <p className="text-right text-[10px] text-nexus-muted mt-0.5">{form.bio.length}/200</p>
              </div>
              <button onClick={handleSaveProfile} disabled={saving} className="btn-nexus w-full flex items-center justify-center gap-2 text-sm">
                {saving ? <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                Save changes
              </button>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-3">Theme</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { val: 'dark', label: 'Dark', icon: Moon },
                    { val: 'light', label: 'Light', icon: Sun },
                  ].map(({ val, label, icon: Icon }) => (
                    <button key={val} onClick={() => setTheme(val)}
                      className={`flex items-center gap-2 p-3 rounded-xl border transition-all text-sm ${theme === val ? 'border-nexus-accent bg-nexus-accent/10 text-nexus-accent-light' : 'border-nexus-border hover:border-nexus-border/80'}`}>
                      <Icon className="w-4 h-4" />
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-nexus-card rounded-xl">
                <div>
                  <p className="text-sm font-medium">Push notifications</p>
                  <p className="text-xs text-nexus-muted">Get notified of new messages</p>
                </div>
                <button onClick={handleNotifToggle}
                  className={`w-11 h-6 rounded-full transition-colors relative ${user?.notifications ? 'bg-nexus-accent' : 'bg-nexus-border'}`}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${user?.notifications ? 'left-6' : 'left-1'}`} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </ModalBase>
  );
}
