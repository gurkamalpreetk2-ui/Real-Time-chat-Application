import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Phone, Video, Info, Search, MoreVertical,
  Archive, Trash2, VolumeX, Bot
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import { useUIStore } from '../../store/uiStore';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import UserAvatar from '../ui/UserAvatar';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function ChatWindow({ onBack }) {
  const { activeChat, typingUsers, onlineUsers, setActiveChat } = useChatStore();
  const { user } = useAuthStore();
  const { openModal } = useUIStore();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef(null);

  const otherParticipant = useMemo(() => {
    if (activeChat?.isGroup || activeChat?.isAIChat) return null;
    return activeChat?.participants?.find((p) => {
      const pid = p._id || p;
      return pid?.toString() !== user?._id?.toString();
    }) || null;
  }, [activeChat, user]);

  const liveStatus = otherParticipant ? (onlineUsers[otherParticipant._id] || null) : null;
  const status = liveStatus?.status || otherParticipant?.status || 'offline';

  const typingInChat = typingUsers[activeChat?._id];
  const typingNames = useMemo(() => {
    if (!typingInChat) return [];
    return Object.entries(typingInChat)
      .filter(([uid, t]) => t.isTyping && uid !== user?._id?.toString())
      .map(([, t]) => t.userName);
  }, [typingInChat, user?._id]);

  // Close menu on outside click
  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setShowMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleArchive = async () => {
    try {
      await api.put(`/chats/${activeChat._id}/archive`);
      toast.success('Chat archived');
      setActiveChat(null);
    } catch { toast.error('Failed to archive'); }
    setShowMenu(false);
  };

  const handleMute = async () => {
    try {
      const { data } = await api.put(`/chats/${activeChat._id}/mute`);
      toast.success(data.muted ? 'Notifications muted' : 'Unmuted');
    } catch { toast.error('Failed'); }
    setShowMenu(false);
  };

  const displayName = activeChat?.isAIChat
    ? 'Nexus AI'
    : activeChat?.isGroup
    ? (activeChat.name || 'Group')
    : (otherParticipant?.name || 'Chat');

  const subtitleText = useMemo(() => {
    if (activeChat?.isAIChat) return 'Always online · Powered by Groq LLaMA';
    if (activeChat?.isGroup) return `${activeChat.participants?.length || 0} members`;
    if (typingNames.length > 0) return `${typingNames[0]} is typing…`;
    if (status === 'online') return 'Online';
    const lastSeen = liveStatus?.lastSeen || otherParticipant?.lastSeen;
    if (lastSeen) {
      try { return `Last seen ${formatDistanceToNow(new Date(lastSeen), { addSuffix: true })}`; }
      catch { /* ignore invalid date */ }
    }
    return 'Offline';
  }, [activeChat, typingNames, status, liveStatus, otherParticipant]);

  const menuActions = [
    { icon: Archive, label: 'Archive chat', action: handleArchive },
    { icon: VolumeX, label: 'Mute notifications', action: handleMute },
    { icon: Info, label: 'Chat info', action: () => { openModal('userProfile', otherParticipant); setShowMenu(false); }, show: !!otherParticipant },
    { icon: Trash2, label: 'Delete chat', action: () => { openModal('deleteChat', activeChat); setShowMenu(false); }, danger: true },
  ].filter((a) => a.show !== false);

  return (
    <div className="flex flex-col h-full bg-nexus-bg">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-nexus-border bg-nexus-surface flex-shrink-0">
        <button onClick={onBack} className="md:hidden btn-ghost p-1.5 flex-shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </button>

        <button
          className="flex items-center gap-3 flex-1 min-w-0 text-left"
          onClick={() => !activeChat?.isAIChat && otherParticipant && openModal('userProfile', otherParticipant)}
        >
          {activeChat?.isAIChat ? (
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-nexus-accent to-indigo-500 flex items-center justify-center flex-shrink-0">
              <Bot className="w-5 h-5 text-white" />
            </div>
          ) : (
            <UserAvatar
              user={activeChat?.isGroup
                ? { name: activeChat.name, avatar: activeChat.groupAvatar }
                : otherParticipant}
              size="md"
              showStatus={!activeChat?.isGroup && !activeChat?.isAIChat}
              statusOverride={status}
            />
          )}
          <div className="min-w-0">
            <p className="font-semibold text-sm truncate">{displayName}</p>
            <p className={`text-xs truncate ${typingNames.length > 0 ? 'text-nexus-accent-light italic' : 'text-nexus-muted'}`}>
              {subtitleText}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-0.5 flex-shrink-0">
          <button className="btn-ghost p-2" title="Voice call"><Phone className="w-4 h-4" /></button>
          <button className="btn-ghost p-2" title="Video call"><Video className="w-4 h-4" /></button>
          <button className="btn-ghost p-2" title="Search messages"><Search className="w-4 h-4" /></button>

          <div className="relative" ref={menuRef}>
            <button className="btn-ghost p-2" onClick={() => setShowMenu((v) => !v)}>
              <MoreVertical className="w-4 h-4" />
            </button>
            <AnimatePresence>
              {showMenu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -6 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -6 }}
                  transition={{ duration: 0.12 }}
                  className="absolute right-0 top-10 w-48 glass rounded-xl shadow-nexus-lg z-50 overflow-hidden py-1"
                >
                  {menuActions.map(({ icon: Icon, label, action, danger }) => (
                    <button
                      key={label}
                      onClick={action}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors hover:bg-nexus-border/50 ${danger ? 'text-nexus-error' : 'text-nexus-text'}`}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      {label}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <MessageList />
      <MessageInput />
    </div>
  );
}
