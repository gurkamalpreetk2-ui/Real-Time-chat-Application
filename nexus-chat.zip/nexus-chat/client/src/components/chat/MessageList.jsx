import { useEffect, useRef, useState, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import MessageBubble from './MessageBubble';
import { format, isToday, isYesterday, isSameDay } from 'date-fns';

function DateSeparator({ date }) {
  let label;
  if (isToday(date)) label = 'Today';
  else if (isYesterday(date)) label = 'Yesterday';
  else label = format(date, 'MMMM d, yyyy');

  return (
    <div className="flex items-center gap-3 my-4 px-4">
      <div className="flex-1 h-px bg-nexus-border" />
      <span className="text-xs text-nexus-muted bg-nexus-surface px-3 py-1 rounded-full flex-shrink-0 select-none">
        {label}
      </span>
      <div className="flex-1 h-px bg-nexus-border" />
    </div>
  );
}

function TypingIndicator({ names }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 4 }}
      className="flex items-end gap-2 px-4 pb-2"
    >
      <div className="bubble-received px-4 py-3 flex items-center gap-1">
        <span className="typing-dot" />
        <span className="typing-dot" />
        <span className="typing-dot" />
      </div>
      {names[0] && (
        <span className="text-xs text-nexus-muted mb-1">{names[0]} is typing</span>
      )}
    </motion.div>
  );
}

function SkeletonMessage({ flip }) {
  return (
    <div className={`flex items-end gap-2 px-4 py-1.5 ${flip ? 'flex-row-reverse' : ''}`}>
      <div className="w-8 h-8 rounded-full skeleton flex-shrink-0" />
      <div
        className="skeleton rounded-2xl"
        style={{ width: `${110 + Math.random() * 140}px`, height: '40px' }}
      />
    </div>
  );
}

export default function MessageList() {
  const { activeChat, messages, messagesLoading, typingUsers, fetchMessages } = useChatStore();
  const { user } = useAuthStore();
  const bottomRef = useRef(null);
  const containerRef = useRef(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const isInitialLoad = useRef(true);

  const chatMessages = messages[activeChat?._id] || [];

  const typingInChat = typingUsers[activeChat?._id];
  const typingNames = typingInChat
    ? Object.entries(typingInChat)
        .filter(([uid, t]) => t.isTyping && uid !== user?._id?.toString())
        .map(([, t]) => t.userName)
    : [];

  const scrollToBottom = useCallback((smooth = true) => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'instant' });
    }
  }, []);

  // On chat change: reset + load
  useEffect(() => {
    if (!activeChat?._id) return;
    setPage(1);
    setHasMore(false);
    isInitialLoad.current = true;

    fetchMessages(activeChat._id, 1).then((pagination) => {
      setHasMore(pagination?.hasMore || false);
      // Wait for render then scroll
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          scrollToBottom(false);
          isInitialLoad.current = false;
        });
      });
    });
  }, [activeChat?._id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Scroll to bottom on new messages (only if near bottom)
  useEffect(() => {
    if (isInitialLoad.current) return;
    const container = containerRef.current;
    if (!container) return;
    const distFromBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
    if (distFromBottom < 160) {
      scrollToBottom(true);
    }
  }, [chatMessages.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleScroll = useCallback(async () => {
    const container = containerRef.current;
    if (!container) return;

    const distFromBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
    setShowScrollBtn(distFromBottom > 300);

    // Load more when scrolled near top
    if (container.scrollTop < 80 && hasMore && !loadingMore && !messagesLoading) {
      setLoadingMore(true);
      const prevHeight = container.scrollHeight;
      const nextPage = page + 1;
      const pagination = await fetchMessages(activeChat._id, nextPage);
      setPage(nextPage);
      setHasMore(pagination?.hasMore || false);
      // Restore scroll position after prepending messages
      requestAnimationFrame(() => {
        if (containerRef.current) {
          containerRef.current.scrollTop = containerRef.current.scrollHeight - prevHeight;
        }
      });
      setLoadingMore(false);
    }
  }, [hasMore, loadingMore, messagesLoading, page, activeChat?._id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Group by date
  const groups = [];
  let lastDate = null;
  chatMessages.forEach((msg, i) => {
    const d = new Date(msg.createdAt);
    if (!lastDate || !isSameDay(lastDate, d)) {
      groups.push({ type: 'date', date: d, key: `date-${i}` });
      lastDate = d;
    }
    groups.push({ type: 'message', msg, key: msg._id || `tmp-${i}` });
  });

  // Skeleton while loading first batch
  if (messagesLoading && chatMessages.length === 0) {
    return (
      <div className="flex-1 overflow-hidden flex flex-col justify-end py-2">
        {[...Array(6)].map((_, i) => (
          <SkeletonMessage key={i} flip={i % 2 === 1} />
        ))}
      </div>
    );
  }

  return (
    <div className="flex-1 relative overflow-hidden">
      {/* subtle dot pattern */}
      <div className="absolute inset-0 opacity-[0.012] pointer-events-none" style={{
        backgroundImage: 'radial-gradient(#7c3aed 1px, transparent 1px)',
        backgroundSize: '28px 28px',
      }} />

      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-full overflow-y-auto relative"
      >
        {/* Load more spinner */}
        {(loadingMore) && (
          <div className="flex justify-center py-3">
            <div className="w-5 h-5 border-2 border-nexus-border border-t-nexus-accent rounded-full animate-spin" />
          </div>
        )}

        {/* Empty state */}
        {chatMessages.length === 0 && !messagesLoading && (
          <div className="flex flex-col items-center justify-center h-full text-center px-4 py-8">
            <div className="w-14 h-14 rounded-full bg-nexus-border mb-4 flex items-center justify-center">
              <span className="text-2xl">💬</span>
            </div>
            <p className="text-nexus-muted text-sm">No messages yet</p>
            <p className="text-nexus-muted/60 text-xs mt-1">Be the first to say something!</p>
          </div>
        )}

        {/* Message list */}
        <div className="px-2 py-2">
          <AnimatePresence initial={false}>
            {groups.map((item) =>
              item.type === 'date' ? (
                <DateSeparator key={item.key} date={item.date} />
              ) : (
                <MessageBubble key={item.key} message={item.msg} />
              )
            )}
          </AnimatePresence>
        </div>

        {/* Typing indicator */}
        <AnimatePresence>
          {typingNames.length > 0 && <TypingIndicator key="typing" names={typingNames} />}
        </AnimatePresence>

        <div ref={bottomRef} className="h-1" />
      </div>

      {/* Scroll to bottom button */}
      <AnimatePresence>
        {showScrollBtn && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => scrollToBottom()}
            className="absolute bottom-4 right-4 w-9 h-9 rounded-full bg-nexus-accent shadow-nexus flex items-center justify-center z-10 hover:bg-nexus-accent-light transition-colors"
          >
            <ArrowDown className="w-4 h-4 text-white" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
