import { motion } from 'framer-motion';
import { Zap, MessageSquare, Bot, Users } from 'lucide-react';

export default function EmptyState() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 bg-nexus-bg relative overflow-hidden">
      {/* Subtle animated background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-1/3 w-80 h-80 bg-nexus-accent/5 rounded-full blur-3xl animate-pulse-soft" />
        <div className="absolute bottom-1/3 right-1/3 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: '1s' }} />
      </div>
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: 'radial-gradient(#7c3aed 1px, transparent 1px)',
        backgroundSize: '40px 40px'
      }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 text-center max-w-sm"
      >
        {/* Logo icon */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1, type: 'spring', stiffness: 200 }}
          className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-nexus-accent/15 border border-nexus-accent/20 mb-6 glow-accent"
        >
          <Zap className="w-10 h-10 text-nexus-accent-light" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-2xl font-display font-bold text-gradient mb-2"
        >
          Welcome to Nexus
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-nexus-muted text-sm mb-8"
        >
          Select a conversation or search for someone to start messaging
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-3 gap-3"
        >
          {[
            { icon: MessageSquare, label: 'Chat', desc: 'Real-time' },
            { icon: Bot, label: 'AI', desc: 'Powered' },
            { icon: Users, label: 'Groups', desc: 'Together' },
          ].map(({ icon: Icon, label, desc }) => (
            <div key={label} className="glass rounded-xl p-4 text-center">
              <Icon className="w-5 h-5 text-nexus-accent-light mx-auto mb-2" />
              <p className="text-xs font-medium text-nexus-text">{label}</p>
              <p className="text-[10px] text-nexus-muted">{desc}</p>
            </div>
          ))}
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-nexus-muted/40 text-xs mt-8"
        >
          End-to-end encrypted · AI-powered · Real-time
        </motion.p>
      </motion.div>
    </div>
  );
}
