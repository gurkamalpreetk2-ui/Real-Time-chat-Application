import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Reply, Forward, Trash2, Copy, Star, Pin, MoreHorizontal,
  Check, CheckCheck, Clock, Pencil, RotateCcw
} from 'lucide-react';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import { useUIStore } from '../../store/uiStore';
import UserAvatar from '../ui/UserAvatar';
import api from '../../services/api';
import toast from 'react-hot-toast';

const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

function StatusIcon({ status }) {
  if (status === 'sending') return <Clock className="w-3 h-3 text-nexus-muted" />;
  if (status === 'sent') return <Check className="w-3 h-3 text-nexus-muted" />;
  if (status === 'delivered') return <CheckCheck className="w-3 h-3 text-nexus-muted" />;
  if (status === 'read') return <CheckCheck className="w-3 h-3 text-blue-400" />;
  return null;
}

function MarkdownContent({ content }) {
  return (
    <div className="markdown-content text-sm leading-relaxed">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code({ node, inline, className, children, ...props }) {
            const lang = /language-(\w+)/.exec(className || '')?.[1];
            return !inline && lang ? (
              <SyntaxHighlighter
                style={oneDark}
                language={lang}
                PreTag="div"
                className="rounded-lg !text-xs !my-2"
                {...props}
              >
                {String(children).replace(/\n$/, '')}
              </SyntaxHighlighter>
            ) : (
              <code className={`${className || ''} bg-black/20 rounded px-1 py-0.5 text-xs font-mono`} {...props}>
                {children}
              </code>
            );
          },
        }}
      >
        {content || ''}
      </ReactMarkdown>
    </div>
  );
}

function AttachmentContent({ attachments, content }) {
  return (
    <div className="space-y-2 max-w-xs">
      {attachments.map((att, i) => (
        <div key={i}>
          {att.type === 'image' && (
            <img src={att.url} alt={att.name || 'image'} className="rounded-xl max-h-60 object-cover cursor-pointer hover:opacity-90 transition-opacity w-full" />
          )}
          {att.type === 'video' && (
            <video src={att.url} controls className="rounded-xl max-w-full" />
          )}
          {att.type === 'audio' && (
            <audio src={att.url} controls className="w-full" />
          )}
          {att.type === 'document' && (
            <a href={att.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 bg-black/20 rounded-xl p-3 hover:bg-black/30 transition-colors">
              <span className="text-2xl flex-shrink-0">📎</span>
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{att.name || 'File'}</p>
                {att.size && <p className="text-xs opacity-60">{(att.size / 1024).toFixed(1)} KB</p>}
              </div>
            </a>
          )}
        </div>
      ))}
      {content && content !== '🎤 Voice message' && (
        <p className="text-sm whitespace-pre-wrap break-words mt-1">{content}</p>
      )}
    </div>
  );
}

export default function MessageBubble({ message }) {
  const { user } = useAuthStore();
  const { updateMessage, activeChat } = useChatStore();
  const { openModal, setReplyTo } = useUIStore();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef(null);

  const senderId = message.sender?._id || message.sender;
  const myId = user?._id;
  const isMine = senderId?.toString() === myId?.toString();
  const isAI = message.type === 'ai';
  const isDeleted = message.deletedForEveryone;
  const isUnsent = message.unsent;
  const isStreaming = message.streaming;

  // Close menu on outside click
  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setShowMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Hide if deleted for me
  if (message.deletedFor?.some?.((id) => id?.toString() === myId?.toString())) return null;

  // System message
  if (message.type === 'system') {
    return (
      <div className="flex justify-center my-2 px-4">
        <span className="text-xs text-nexus-muted bg-nexus-border/50 px-3 py-1 rounded-full">
          {message.content}
        </span>
      </div>
    );
  }

  const handleReact = async (emoji) => {
    try {
      const { data } = await api.put(`/messages/${message._id}/react`, { emoji });
      updateMessage(message._id, { reactions: data.reactions });
    } catch { toast.error('Failed to react'); }
    setShowMenu(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content || '');
    toast.success('Copied to clipboard');
    setShowMenu(false);
  };

  const handleStar = async () => {
    try {
      const { data } = await api.put(`/messages/${message._id}/star`);
      toast.success(data.starred ? '⭐ Starred' : 'Unstarred');
    } catch { toast.error('Failed'); }
    setShowMenu(false);
  };

  const handlePin = async () => {
    try {
      await api.put(`/messages/${message._id}/pin`);
      toast.success('Pin updated');
    } catch { toast.error('Failed'); }
    setShowMenu(false);
  };

  const handleUnsend = async () => {
    try {
      await api.put(`/messages/${message._id}/unsend`);
    } catch (err) { toast.error(err.response?.data?.error || 'Cannot unsend'); }
    setShowMenu(false);
  };

  const menuItems = [
    { icon: Reply, label: 'Reply', action: () => { setReplyTo(message); setShowMenu(false); } },
    { icon: Copy, label: 'Copy text', action: handleCopy, show: !isDeleted && !isUnsent && !!message.content },
    { icon: Forward, label: 'Forward', action: () => { openModal('forwardMessage', message); setShowMenu(false); }, show: !isDeleted && !isUnsent },
    { icon: Star, label: 'Star message', action: handleStar, show: !isDeleted && !isUnsent },
    { icon: Pin, label: message.pinned ? 'Unpin' : 'Pin message', action: handlePin },
    { icon: RotateCcw, label: 'Unsend', action: handleUnsend, show: isMine && !isUnsent && !isDeleted },
    { icon: Trash2, label: 'Delete for me', action: () => { openModal('deleteMessage', { message, type: 'me' }); setShowMenu(false); } },
    { icon: Trash2, label: 'Delete for everyone', action: () => { openModal('deleteMessage', { message, type: 'everyone' }); setShowMenu(false); }, show: isMine && !isDeleted, danger: true },
  ].filter((item) => item.show !== false);

  const bubbleClass = isMine
    ? 'bubble-sent text-white'
    : isAI
    ? 'bubble-ai'
    : 'bubble-received';

  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.18, ease: [0.34, 1.56, 0.64, 1] }}
      className={`flex items-end gap-2 px-2 py-0.5 group/row ${isMine ? 'flex-row-reverse' : ''}`}
    >
      {/* Avatar (other user) */}
      {!isMine && (
        <div className="flex-shrink-0 mb-1 self-end">
          <UserAvatar user={message.sender} size="sm" />
        </div>
      )}

      <div className={`flex flex-col max-w-[75%] md:max-w-[65%] ${isMine ? 'items-end' : 'items-start'}`}>
        {/* Sender name for groups */}
        {!isMine && activeChat?.isGroup && (
          <span className="text-xs text-nexus-accent-light mb-1 px-1 font-medium">
            {message.sender?.name || 'User'}
          </span>
        )}

        {/* Reply preview */}
        {message.replyTo && (
          <div className="mb-1.5 px-3 py-2 rounded-xl border-l-2 border-nexus-accent bg-nexus-border/40 text-xs max-w-full">
            <span className="text-nexus-accent-light font-medium block truncate">
              {message.replyTo.sender?.name || 'User'}
            </span>
            <span className="text-nexus-muted truncate block">
              {message.replyTo.content?.slice(0, 60) || 'Attachment'}
            </span>
          </div>
        )}

        {/* Bubble */}
        <div className="relative" ref={menuRef}>
          {/* Quick-reaction hover bar */}
          <div className={`absolute ${isMine ? 'right-0' : 'left-0'} -top-8 hidden group-hover/row:flex items-center gap-1 bg-nexus-card border border-nexus-border rounded-xl px-2 py-1 shadow-nexus z-20 pointer-events-auto`}>
            {REACTIONS.slice(0, 4).map((e) => (
              <button key={e} onClick={() => handleReact(e)} className="hover:scale-125 transition-transform text-sm leading-none">{e}</button>
            ))}
            <button onClick={() => setShowMenu(true)} className="text-nexus-muted hover:text-nexus-text ml-0.5">
              <MoreHorizontal className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Message content */}
          <div
            className={`${bubbleClass} px-4 py-2.5 cursor-default select-text`}
            onContextMenu={(e) => { e.preventDefault(); setShowMenu(true); }}
          >
            {isDeleted ? (
              <p className="text-sm italic opacity-60">🚫 This message was deleted</p>
            ) : isUnsent ? (
              <p className="text-sm italic opacity-60">↩ This message was removed</p>
            ) : isStreaming ? (
              <div>
                {message.content ? (
                  <MarkdownContent content={message.content} />
                ) : (
                  <div className="flex items-center gap-1.5 text-nexus-muted py-0.5">
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                  </div>
                )}
              </div>
            ) : isAI ? (
              <MarkdownContent content={message.content} />
            ) : message.attachments?.length > 0 ? (
              <AttachmentContent attachments={message.attachments} content={message.content} />
            ) : (
              <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>
            )}

            {/* Timestamp + status */}
            {!isStreaming && (
              <div className={`flex items-center gap-1 mt-1.5 ${isMine ? 'justify-end' : 'justify-start'}`}>
                <span className="text-[10px] opacity-50">
                  {format(new Date(message.createdAt), 'HH:mm')}
                </span>
                {message.edited && <span className="text-[10px] opacity-40 italic">edited</span>}
                {isMine && <StatusIcon status={message.status} />}
              </div>
            )}
          </div>

          {/* Reactions */}
          {message.reactions?.length > 0 && (
            <div className={`flex flex-wrap gap-1 mt-1 ${isMine ? 'justify-end' : 'justify-start'}`}>
              {message.reactions.map((r) => (
                <button
                  key={r.emoji}
                  onClick={() => handleReact(r.emoji)}
                  className="flex items-center gap-1 bg-nexus-card border border-nexus-border rounded-full px-2 py-0.5 text-xs hover:border-nexus-accent/50 transition-colors"
                >
                  <span>{r.emoji}</span>
                  <span className="text-nexus-muted">{r.users?.length || 0}</span>
                </button>
              ))}
            </div>
          )}

          {/* Context menu */}
          <AnimatePresence>
            {showMenu && (
              <motion.div
                initial={{ opacity: 0, scale: 0.92, y: -4 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.92, y: -4 }}
                transition={{ duration: 0.12 }}
                className={`absolute ${isMine ? 'right-0' : 'left-0'} top-full mt-1 w-52 glass rounded-xl shadow-nexus-lg z-50 overflow-hidden py-1`}
              >
                {/* Reaction row */}
                <div className="flex items-center justify-around px-3 py-2 border-b border-nexus-border">
                  {REACTIONS.map((e) => (
                    <button key={e} onClick={() => handleReact(e)} className="text-lg hover:scale-125 transition-transform">{e}</button>
                  ))}
                </div>
                {menuItems.map(({ icon: Icon, label, action, danger }) => (
                  <button
                    key={label}
                    onClick={action}
                    className={`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors hover:bg-nexus-border/50 ${danger ? 'text-nexus-error' : 'text-nexus-text'}`}
                  >
                    <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                    {label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
