import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send, Smile, Paperclip, Mic, MicOff, X, Bot,
  Image, FileText, Film, Volume2
} from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';
import { v4 as uuidv4 } from 'uuid';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import { useUIStore } from '../../store/uiStore';
import { emitTypingStart, emitTypingStop } from '../../services/socket';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function MessageInput() {
  const [content, setContent] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isAIProcessing, setIsAIProcessing] = useState(false);
  const [suggestions, setSuggestions] = useState([]);

  const inputRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const emojiRef = useRef(null);
  const attachRef = useRef(null);

  const {
    activeChat, addMessage,
    addStreamingMessage, appendStreamingContent, removeStreamingMessage,
    messages,
  } = useChatStore();
  const { user } = useAuthStore();
  const { replyTo, clearReplyTo } = useUIStore();

  const isAIChat = activeChat?.isAIChat;

  // Reset on chat change
  useEffect(() => {
    setContent('');
    setSuggestions([]);
    setShowEmoji(false);
    setShowAttach(false);
    inputRef.current?.focus();
  }, [activeChat?._id]);

  // Close pickers on outside click
  useEffect(() => {
    const handler = (e) => {
      if (emojiRef.current && !emojiRef.current.contains(e.target)) setShowEmoji(false);
      if (attachRef.current && !attachRef.current.contains(e.target)) setShowAttach(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleTyping = useCallback((val) => {
    setContent(val);
    if (!activeChat?._id) return;
    emitTypingStart(activeChat._id);
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => emitTypingStop(activeChat._id), 1500);
  }, [activeChat?._id]);

  const fetchSuggestions = useCallback(async () => {
    if (!activeChat?._id) return;
    const chatMsgs = messages[activeChat._id] || [];
    if (chatMsgs.length < 2) return;
    try {
      const recent = chatMsgs.slice(-5).map((m) => ({
        content: m.content,
        senderName: m.sender?.name || 'User',
      }));
      const { data } = await api.post('/ai/suggest-replies', { messages: recent });
      if (Array.isArray(data.suggestions)) setSuggestions(data.suggestions.slice(0, 3));
    } catch { /* non-critical, ignore */ }
  }, [activeChat?._id, messages]);

  const sendMessage = useCallback(async (
    msgContent = content,
    type = 'text',
    attachments = []
  ) => {
    const trimmed = typeof msgContent === 'string' ? msgContent.trim() : '';
    if (!trimmed && !attachments.length) return;
    if (!activeChat?._id || isSending || isAIProcessing) return;

    setIsSending(true);
    clearReplyTo();
    clearTimeout(typingTimeoutRef.current);
    emitTypingStop(activeChat._id);

    const chatId = activeChat._id;

    try {
      if (isAIChat) {
        setContent('');
        const chatMsgs = messages[chatId] || [];

        // 1) Save user message
        const { data: userMsgData } = await api.post('/messages', {
          chatId,
          content: trimmed,
          type: 'text',
          replyTo: replyTo?._id,
        });
        addMessage(userMsgData.message);

        // 2) Show streaming placeholder
        const tempId = `streaming-${uuidv4()}`;
        addStreamingMessage(chatId, tempId);
        setIsAIProcessing(true);
        setIsSending(false);

        // 3) Stream AI response
        const stored = JSON.parse(localStorage.getItem('nexus-auth') || '{}');
        const token = stored?.state?.accessToken || '';

        const response = await fetch('/api/ai/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            chatId,
            message: trimmed,
            conversationHistory: chatMsgs.slice(-10),
          }),
        });

        if (!response.ok) {
          const err = await response.json().catch(() => ({}));
          throw new Error(err.error || 'AI request failed');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop(); // keep incomplete last line

          for (const line of lines) {
            if (!line.startsWith('data: ')) continue;
            try {
              const parsed = JSON.parse(line.slice(6));
              if (parsed.type === 'delta' && parsed.text) {
                appendStreamingContent(chatId, tempId, parsed.text);
              } else if (parsed.type === 'done') {
                removeStreamingMessage(chatId, tempId);
              } else if (parsed.type === 'error') {
                throw new Error(parsed.error || 'AI error');
              }
            } catch (e) {
              if (e.message !== 'AI error') { /* parse error, ignore */ }
              else throw e;
            }
          }
        }

        setIsAIProcessing(false);
        fetchSuggestions();

      } else {
        // Regular message
        const { data } = await api.post('/messages', {
          chatId,
          content: trimmed,
          type,
          attachments,
          replyTo: replyTo?._id,
        });
        addMessage(data.message);
        setContent('');
        fetchSuggestions();
        setIsSending(false);
      }
    } catch (err) {
      toast.error(err.message || 'Failed to send message');
      removeStreamingMessage(chatId, `streaming-`); // cleanup any temp
      setIsAIProcessing(false);
      setIsSending(false);
    }

    inputRef.current?.focus();
  }, [content, activeChat?._id, isSending, isAIProcessing, isAIChat, replyTo, messages]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
    if (e.key === 'Escape') clearReplyTo();
  };

  const handleEmojiClick = (emojiData) => {
    const cursor = inputRef.current?.selectionStart ?? content.length;
    const next = content.slice(0, cursor) + emojiData.emoji + content.slice(cursor);
    setContent(next);
    setShowEmoji(false);
    setTimeout(() => inputRef.current?.focus(), 10);
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const formData = new FormData();
    files.forEach((f) => formData.append('files', f));
    try {
      toast.loading('Uploading...', { id: 'upload' });
      const { data } = await api.post('/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('Uploaded!', { id: 'upload' });
      await sendMessage('', data.files[0]?.type || 'file', data.files);
    } catch {
      toast.error('Upload failed', { id: 'upload' });
    }
    e.target.value = '';
    setShowAttach(false);
  };

  const toggleRecording = async () => {
    if (!isRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;
        audioChunksRef.current = [];
        recorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
        recorder.onstop = async () => {
          const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const fd = new FormData();
          fd.append('files', blob, 'voice.webm');
          try {
            const { data } = await api.post('/upload', fd, {
              headers: { 'Content-Type': 'multipart/form-data' },
            });
            await sendMessage('🎤 Voice message', 'audio', data.files);
          } catch { toast.error('Failed to send voice'); }
          stream.getTracks().forEach((t) => t.stop());
        };
        recorder.start();
        setIsRecording(true);
        toast('🎤 Recording — tap mic to stop', { id: 'rec', duration: 60000 });
      } catch {
        toast.error('Microphone access denied');
      }
    } else {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
      toast.dismiss('rec');
    }
  };

  const isDisabled = isSending || isAIProcessing;

  return (
    <div className="flex-shrink-0 border-t border-nexus-border bg-nexus-surface">
      {/* Reply preview */}
      <AnimatePresence>
        {replyTo && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex items-center gap-3 px-4 py-2 border-b border-nexus-border bg-nexus-card overflow-hidden"
          >
            <div className="flex-1 min-w-0 border-l-2 border-nexus-accent pl-3">
              <p className="text-xs text-nexus-accent-light font-medium truncate">
                {replyTo.sender?.name || 'User'}
              </p>
              <p className="text-xs text-nexus-muted truncate">{replyTo.content?.slice(0, 80)}</p>
            </div>
            <button onClick={clearReplyTo} className="text-nexus-muted hover:text-nexus-text p-1 flex-shrink-0">
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI suggestions */}
      <AnimatePresence>
        {suggestions.length > 0 && !content && !isDisabled && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="flex items-center gap-2 px-4 py-2 overflow-x-auto no-scrollbar border-b border-nexus-border/50"
          >
            <Bot className="w-3.5 h-3.5 text-nexus-accent-light flex-shrink-0" />
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => { sendMessage(s); setSuggestions([]); }}
                className="flex-shrink-0 text-xs px-3 py-1.5 rounded-full border border-nexus-accent/30 text-nexus-accent-light hover:bg-nexus-accent/10 transition-colors whitespace-nowrap"
              >
                {s}
              </button>
            ))}
            <button onClick={() => setSuggestions([])} className="text-nexus-muted hover:text-nexus-text flex-shrink-0 ml-auto">
              <X className="w-3 h-3" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main input row */}
      <div className="flex items-end gap-2 p-3">
        {/* Emoji picker */}
        <div className="relative flex-shrink-0" ref={emojiRef}>
          <button
            onClick={() => { setShowEmoji((v) => !v); setShowAttach(false); }}
            className={`btn-ghost p-2 ${showEmoji ? 'text-nexus-accent-light' : ''}`}
            title="Emoji"
          >
            <Smile className="w-5 h-5" />
          </button>
          <AnimatePresence>
            {showEmoji && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 8 }}
                className="absolute bottom-12 left-0 z-50 shadow-nexus-lg"
              >
                <EmojiPicker
                  onEmojiClick={handleEmojiClick}
                  theme="dark"
                  width={300}
                  height={360}
                  previewConfig={{ showPreview: false }}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Attachment picker */}
        <div className="relative flex-shrink-0" ref={attachRef}>
          <button
            onClick={() => { setShowAttach((v) => !v); setShowEmoji(false); }}
            className={`btn-ghost p-2 ${showAttach ? 'text-nexus-accent-light' : ''}`}
            title="Attach file"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          <AnimatePresence>
            {showAttach && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 8 }}
                className="absolute bottom-12 left-0 glass rounded-xl p-2 space-y-1 w-44 z-50 shadow-nexus-lg"
              >
                {[
                  { icon: Image, label: 'Images', accept: 'image/*' },
                  { icon: Film, label: 'Videos', accept: 'video/*' },
                  { icon: Volume2, label: 'Audio', accept: 'audio/*' },
                  { icon: FileText, label: 'Documents', accept: '.pdf,.doc,.docx,.txt' },
                ].map(({ icon: Icon, label, accept }) => (
                  <button
                    key={label}
                    onClick={() => { fileInputRef.current.accept = accept; fileInputRef.current.click(); }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-nexus-border/50 text-sm transition-colors text-left"
                  >
                    <Icon className="w-4 h-4 text-nexus-muted flex-shrink-0" />
                    {label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <input ref={fileInputRef} type="file" multiple className="hidden" onChange={handleFileChange} />

        {/* Text area */}
        <div className="flex-1 relative min-w-0">
          <textarea
            ref={inputRef}
            value={content}
            onChange={(e) => handleTyping(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isAIChat ? 'Ask Nexus AI anything...' : 'Type a message... (Enter to send, Shift+Enter for newline)'}
            rows={1}
            disabled={isDisabled}
            className="input-nexus w-full text-sm leading-relaxed overflow-y-auto disabled:opacity-50"
            style={{ resize: 'none', minHeight: '42px', maxHeight: '120px' }}
            onInput={(e) => {
              e.target.style.height = 'auto';
              e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
            }}
          />
          {isAIProcessing && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-0.5 pointer-events-none">
              <span className="typing-dot" />
              <span className="typing-dot" />
              <span className="typing-dot" />
            </div>
          )}
        </div>

        {/* Send / Mic */}
        {content.trim() ? (
          <motion.button
            key="send"
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.7, opacity: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => sendMessage()}
            disabled={isDisabled}
            className="flex-shrink-0 w-10 h-10 rounded-xl bg-nexus-accent hover:bg-nexus-accent-light flex items-center justify-center transition-colors shadow-nexus disabled:opacity-60"
          >
            {isSending ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Send className="w-4 h-4 text-white" />
            )}
          </motion.button>
        ) : (
          <button
            key="mic"
            onClick={toggleRecording}
            disabled={isDisabled}
            className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all disabled:opacity-50 ${
              isRecording
                ? 'bg-nexus-error animate-pulse-soft shadow-nexus'
                : 'bg-nexus-card hover:bg-nexus-border text-nexus-muted hover:text-nexus-text'
            }`}
          >
            {isRecording ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
}
