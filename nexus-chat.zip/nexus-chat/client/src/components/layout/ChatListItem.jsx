import { useMemo } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Pin, VolumeX, Bot } from 'lucide-react';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import UserAvatar from '../ui/UserAvatar';

export default function ChatListItem({ chat, onClick }) {
  const { activeChat, unreadCounts, typingUsers, onlineUsers } = useChatStore();
  const { user } = useAuthStore();

  const isActive = activeChat?._id === chat._id;
  const unread = unreadCounts[chat._id] || 0;

  const typingInChat = typingUsers[chat._id];
  const isTyping = typingInChat && Object.values(typingInChat).some((t) => t.isTyping);

  const otherParticipant = useMemo(() => {
    if (chat.isGroup || chat.isAIChat) return null;
    return chat.participants?.find((p) => {
      const pid = p._id || p;
      return pid?.toString() !== user?._id?.toString();
    });
  }, [chat, user]);

  const liveStatus = otherParticipant
    ? onlineUsers[otherParticipant._id || otherParticipant]
    : null;

  const statusOverride = liveStatus?.status || otherParticipant?.status;

  const displayName = chat.isAIChat
    ? 'Nexus AI'
    : chat.isGroup
    ? chat.name
    : otherParticipant?.name || 'Unknown';

  const lastMsgPreview = useMemo(() => {
    const msg = chat.lastMessage;
    if (!msg) return 'Start a conversation';
    if (msg.unsent) return '↩ Message removed';
    if (msg.deletedForEveryone) return '🚫 Message deleted';
    if (msg.attachments?.length) {
      const t = msg.attachments[0]?.type;
      if (t === 'image') return '📷 Image';
      if (t === 'video') return '🎥 Video';
      if (t === 'audio') return '🎤 Voice';
      return '📎 File';
    }
    return (msg.content || '').slice(0, 60);
  }, [chat.lastMessage]);

  const timeStr = useMemo(() => {
    const ts = chat.lastMessage?.createdAt || chat.updatedAt;
    if (!ts) return '';
    try {
      return formatDistanceToNow(new Date(ts), { addSuffix: false })
        .replace('about ', '')
        .replace(' minutes', 'm').replace(' minute', 'm')
        .replace(' hours', 'h').replace(' hour', 'h')
        .replace(' days', 'd').replace(' day', 'd')
        .replace(' months', 'mo').replace(' month', 'mo');
    } catch { return ''; }
  }, [chat.lastMessage?.createdAt, chat.updatedAt]);

  const isPinned = user?.pinnedChats?.some?.((id) => id?.toString() === chat._id);
  const isMuted = user?.mutedChats?.some?.((id) => id?.toString() === chat._id);

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left border ${
        isActive
          ? 'bg-nexus-accent/15 border-nexus-accent/25'
          : 'border-transparent hover:bg-nexus-card hover:border-nexus-border/40'
      }`}
    >
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        {chat.isAIChat ? (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-nexus-accent to-indigo-500 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
        ) : (
          <UserAvatar
            user={chat.isGroup ? { name: chat.name, avatar: chat.groupAvatar } : otherParticipant}
            size="md"
            showStatus={!chat.isGroup && !chat.isAIChat}
            statusOverride={statusOverride}
          />
        )}
        {chat.isAIChat && (
          <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-nexus-success border-2 border-nexus-surface" />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-1 mb-0.5">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className={`text-sm font-medium truncate ${isActive ? 'text-nexus-text' : ''}`}>
              {displayName}
            </span>
            {isPinned && <Pin className="w-3 h-3 text-nexus-muted flex-shrink-0" />}
            {isMuted && <VolumeX className="w-3 h-3 text-nexus-muted flex-shrink-0" />}
          </div>
          <span className="text-[11px] text-nexus-muted flex-shrink-0">{timeStr}</span>
        </div>

        <div className="flex items-center justify-between gap-2">
          <p className={`text-xs truncate ${isTyping ? 'text-nexus-accent-light italic' : 'text-nexus-muted'}`}>
            {isTyping ? (
              <span className="flex items-center gap-1">
                <span className="flex gap-0.5">
                  <span className="typing-dot" />
                  <span className="typing-dot" />
                  <span className="typing-dot" />
                </span>
                typing…
              </span>
            ) : lastMsgPreview}
          </p>
          {unread > 0 && (
            <span className="flex-shrink-0 min-w-[18px] h-[18px] rounded-full bg-nexus-accent text-white text-[10px] font-bold flex items-center justify-center px-1">
              {unread > 99 ? '99+' : unread}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
