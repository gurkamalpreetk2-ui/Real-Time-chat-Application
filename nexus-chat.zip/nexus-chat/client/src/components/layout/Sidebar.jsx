import { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Users, BarChart2, Settings, Moon, Sun, X, Bot, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useChatStore } from '../../store/chatStore';
import { useAuthStore } from '../../store/authStore';
import { useUIStore } from '../../store/uiStore';
import ChatListItem from './ChatListItem';
import UserAvatar from '../ui/UserAvatar';
import api from '../../services/api';
import toast from 'react-hot-toast';

const TABS = [
  { id: 'all', label: 'All' },
  { id: 'groups', label: 'Groups' },
  { id: 'pinned', label: 'Pinned' },
];

export default function Sidebar({ onChatSelect }) {
  const [tab, setTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const searchTimeoutRef = useRef(null);

  const { chats, setActiveChat, addChat, unreadCounts } = useChatStore();
  const { user } = useAuthStore();
  const { openModal, theme, setTheme } = useUIStore();
  const navigate = useNavigate();

  const filteredChats = useMemo(() => {
    let list = [...chats];
    if (tab === 'pinned') list = list.filter((c) => user?.pinnedChats?.some?.((id) => id?.toString() === c._id));
    if (tab === 'groups') list = list.filter((c) => c.isGroup);
    return list;
  }, [chats, tab, user]);

  const totalUnread = useMemo(
    () => Object.values(unreadCounts).reduce((a, b) => a + b, 0),
    [unreadCounts]
  );

  const handleSearch = (q) => {
    setSearchQuery(q);
    setSearchMode(!!q.trim());
    clearTimeout(searchTimeoutRef.current);
    if (!q.trim()) { setSearchResults([]); return; }
    setSearching(true);
    searchTimeoutRef.current = setTimeout(async () => {
      try {
        const { data } = await api.get(`/users/search?q=${encodeURIComponent(q.trim())}`);
        setSearchResults(data.users || []);
      } catch { setSearchResults([]); }
      setSearching(false);
    }, 350);
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSearchMode(false);
    setSearchResults([]);
  };

  const startDirectChat = async (userId) => {
    try {
      const { data } = await api.post('/chats/direct', { userId });
      addChat(data.chat);
      setActiveChat(data.chat);
      clearSearch();
      onChatSelect?.();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to start chat');
    }
  };

  const openAIChat = async () => {
    try {
      const { data } = await api.get('/chats/ai');
      addChat(data.chat);
      setActiveChat(data.chat);
      onChatSelect?.();
    } catch {
      toast.error('Failed to open AI chat');
    }
  };

  return (
    <div className="h-full flex flex-col bg-nexus-surface select-none">
      {/* ── Header ─────────────────────────────────────────────────── */}
      <div className="p-4 border-b border-nexus-border flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-nexus-accent/20 border border-nexus-accent/30 flex items-center justify-center">
              <Bot className="w-4 h-4 text-nexus-accent-light" />
            </div>
            <span className="font-display font-bold text-lg text-gradient">Nexus</span>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-0.5">
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="btn-ghost p-1.5" title="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button onClick={() => openModal('createGroup')} className="btn-ghost p-1.5" title="New group">
              <Users className="w-4 h-4" />
            </button>
            <button onClick={() => openModal('settings')} className="btn-ghost p-1.5" title="Settings">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-muted pointer-events-none" />
          <input
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search chats & people…"
            className="input-nexus w-full pl-9 pr-8 text-sm py-2"
          />
          {searchQuery && (
            <button onClick={clearSearch} className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-muted hover:text-nexus-text">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* ── AI Chat button ─────────────────────────────────────────── */}
      <button
        onClick={openAIChat}
        className="mx-3 mt-3 flex-shrink-0 flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-nexus-accent/20 to-indigo-500/20 border border-nexus-accent/20 hover:border-nexus-accent/40 transition-all group"
      >
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-nexus-accent to-indigo-500 flex items-center justify-center flex-shrink-0">
          <Bot className="w-4 h-4 text-white" />
        </div>
        <div className="text-left min-w-0">
          <p className="text-sm font-medium">Nexus AI</p>
          <p className="text-xs text-nexus-muted truncate">Ask me anything…</p>
        </div>
        <div className="ml-auto w-2 h-2 rounded-full bg-nexus-success flex-shrink-0 animate-pulse-soft" />
      </button>

      {/* ── Tabs (only when not searching) ────────────────────────── */}
      {!searchMode && (
        <div className="flex gap-1 px-3 mt-3 flex-shrink-0">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                tab === t.id ? 'bg-nexus-accent text-white' : 'text-nexus-muted hover:text-nexus-text hover:bg-nexus-border/50'
              }`}
            >
              {t.label}
              {t.id === 'all' && totalUnread > 0 && (
                <span className="bg-nexus-error text-white text-[10px] rounded-full px-1.5 leading-4 min-w-[18px] text-center">
                  {totalUnread > 99 ? '99+' : totalUnread}
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {/* ── List ──────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto mt-2 px-2 pb-4">
        {searchMode ? (
          /* Search results */
          searching ? (
            <div className="space-y-1 p-1">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-3 p-3">
                  <div className="w-10 h-10 rounded-full skeleton flex-shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-28 skeleton rounded" />
                    <div className="h-2.5 w-40 skeleton rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : searchResults.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-nexus-muted text-sm">No users found</p>
              <p className="text-nexus-muted/60 text-xs mt-1">Try a different name or email</p>
            </div>
          ) : (
            <div className="space-y-0.5">
              <p className="text-xs text-nexus-muted px-3 py-2 font-medium uppercase tracking-wider">People</p>
              {searchResults.map((u) => (
                <motion.button
                  key={u._id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  onClick={() => startDirectChat(u._id)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-nexus-card transition-colors text-left"
                >
                  <UserAvatar user={u} size="md" showStatus />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{u.name}</p>
                    <p className="text-xs text-nexus-muted truncate">{u.bio || u.email}</p>
                  </div>
                </motion.button>
              ))}
            </div>
          )
        ) : filteredChats.length === 0 ? (
          /* Empty tab */
          <div className="text-center py-12">
            <div className="w-12 h-12 rounded-full bg-nexus-border mx-auto mb-3 flex items-center justify-center">
              {tab === 'groups' ? <Users className="w-6 h-6 text-nexus-muted" /> : <Search className="w-6 h-6 text-nexus-muted" />}
            </div>
            <p className="text-nexus-muted text-sm">
              {tab === 'pinned' ? 'No pinned chats' : tab === 'groups' ? 'No group chats yet' : 'No conversations yet'}
            </p>
            <p className="text-nexus-muted/60 text-xs mt-1">
              {tab === 'all' ? 'Search above to find people' : ''}
            </p>
          </div>
        ) : (
          /* Chat list */
          <AnimatePresence initial={false}>
            {filteredChats.map((chat, i) => (
              <motion.div
                key={chat._id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ delay: Math.min(i * 0.025, 0.15) }}
              >
                <ChatListItem
                  chat={chat}
                  onClick={() => { setActiveChat(chat); onChatSelect?.(); }}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* ── Footer ────────────────────────────────────────────────── */}
      <div className="p-3 border-t border-nexus-border flex-shrink-0">
        <div
          className="flex items-center gap-3 p-2 rounded-xl hover:bg-nexus-card cursor-pointer transition-colors"
          onClick={() => navigate('/profile')}
        >
          <UserAvatar user={user} size="sm" showStatus />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user?.name || 'You'}</p>
            <p className="text-xs text-nexus-muted capitalize">{user?.status || 'offline'}</p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); navigate('/dashboard'); }}
            className="btn-ghost p-1.5 flex-shrink-0" title="Dashboard"
          >
            <BarChart2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
