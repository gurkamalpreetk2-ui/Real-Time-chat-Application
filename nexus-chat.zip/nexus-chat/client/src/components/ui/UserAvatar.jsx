import { useMemo } from 'react';

const sizes = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
  xl: 'w-16 h-16 text-xl',
  '2xl': 'w-24 h-24 text-3xl',
};

const dotSizes = {
  xs: 'w-1.5 h-1.5 border',
  sm: 'w-2 h-2 border-2',
  md: 'w-2.5 h-2.5 border-2',
  lg: 'w-3 h-3 border-2',
  xl: 'w-3.5 h-3.5 border-2',
  '2xl': 'w-4 h-4 border-2',
};

const gradients = [
  'from-purple-500 to-indigo-600',
  'from-pink-500 to-rose-600',
  'from-blue-500 to-cyan-600',
  'from-green-500 to-teal-600',
  'from-orange-500 to-amber-600',
  'from-red-500 to-pink-600',
  'from-violet-500 to-purple-600',
  'from-teal-500 to-green-600',
];

function getGradient(name = '') {
  const idx = name.charCodeAt(0) % gradients.length;
  return gradients[idx];
}

export default function UserAvatar({ user, size = 'md', showStatus = false, statusOverride, className = '' }) {
  const initials = useMemo(() => {
    if (!user?.name) return '?';
    const parts = user.name.trim().split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return user.name.slice(0, 2).toUpperCase();
  }, [user?.name]);

  const gradient = getGradient(user?.name);
  const status = statusOverride || user?.status || 'offline';

  const statusColors = {
    online: 'bg-nexus-online',
    away: 'bg-nexus-away',
    busy: 'bg-nexus-busy',
    offline: 'bg-nexus-offline',
  };

  return (
    <div className={`relative flex-shrink-0 ${className}`}>
      {user?.avatar ? (
        <img
          src={user.avatar}
          alt={user.name}
          className={`${sizes[size]} rounded-full object-cover`}
          onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
        />
      ) : null}
      <div
        className={`${sizes[size]} rounded-full bg-gradient-to-br ${gradient} flex items-center justify-center font-semibold text-white select-none ${user?.avatar ? 'hidden' : 'flex'}`}
      >
        {initials}
      </div>
      {showStatus && (
        <div className={`${dotSizes[size]} ${statusColors[status] || statusColors.offline} rounded-full absolute bottom-0 right-0 border-nexus-surface`} />
      )}
    </div>
  );
}
