import { motion } from 'framer-motion';
import { X } from 'lucide-react';

export default function ModalBase({ title, onClose, children, size = 'sm' }) {
  const widths = { xs: 'max-w-xs', sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-xl' };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 16 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className={`glass rounded-2xl w-full ${widths[size]} shadow-nexus-lg`}
      >
        {(title || onClose) && (
          <div className="flex items-center justify-between px-5 py-4 border-b border-nexus-border">
            {title && <h3 className="font-semibold text-base">{title}</h3>}
            {onClose && (
              <button onClick={onClose} className="btn-ghost p-1.5 ml-auto">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
        {children}
      </motion.div>
    </motion.div>
  );
}
