import { io } from 'socket.io-client';

let socket = null;

export const initSocket = (token) => {
  // Avoid duplicate connections
  if (socket?.connected) return socket;
  if (socket) {
    socket.disconnect();
    socket = null;
  }

  const serverUrl = import.meta.env.VITE_SERVER_URL || 'http://localhost:5000';

  socket = io(serverUrl, {
    auth: { token },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 10000,
    reconnectionAttempts: 10,
    timeout: 20000,
  });

  socket.on('connect', () => {
    console.log('🔌 Socket connected:', socket.id);
  });

  socket.on('connect_error', (err) => {
    console.warn('Socket connection error:', err.message);
  });

  socket.on('disconnect', (reason) => {
    console.log('Socket disconnected:', reason);
  });

  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};

// Convenience emitters — safe to call even before socket is ready
export const emitTypingStart = (chatId) => socket?.emit('typing:start', { chatId });
export const emitTypingStop = (chatId) => socket?.emit('typing:stop', { chatId });
export const emitMessageDelivered = (messageId) => socket?.emit('message:delivered', { messageId });
export const emitMessagesRead = (chatId, messageIds) => socket?.emit('message:read', { chatId, messageIds });
export const joinChat = (chatId) => socket?.emit('chat:join', { chatId });
