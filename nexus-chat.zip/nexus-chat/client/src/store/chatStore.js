import { create } from 'zustand';
import api from '../services/api';

export const useChatStore = create((set, get) => ({
  chats: [],
  activeChat: null,
  messages: {},        // { chatId: Message[] }
  loading: false,
  messagesLoading: false,
  typingUsers: {},     // { chatId: { userId: { name, isTyping } } }
  onlineUsers: {},     // { userId: { status, lastSeen } }
  unreadCounts: {},    // { chatId: number }
  searchQuery: '',
  sidebarOpen: true,

  // Fetch all chats
  fetchChats: async () => {
    set({ loading: true });
    try {
      const { data } = await api.get('/chats');
      const unreadCounts = {};
      data.chats.forEach((c) => { unreadCounts[c._id] = c.unreadCount || 0; });
      set({ chats: data.chats, unreadCounts, loading: false });
    } catch {
      set({ loading: false });
    }
  },

  // Set active chat
  setActiveChat: (chat) => {
    set({ activeChat: chat });
    if (chat) {
      // Clear unread
      set((state) => ({
        unreadCounts: { ...state.unreadCounts, [chat._id]: 0 },
      }));
    }
  },

  // Fetch messages for a chat
  fetchMessages: async (chatId, page = 1) => {
    set({ messagesLoading: true });
    try {
      const { data } = await api.get(`/messages/${chatId}?page=${page}&limit=50`);
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: page === 1 ? data.messages : [...data.messages, ...(state.messages[chatId] || [])],
        },
        messagesLoading: false,
      }));
      return data.pagination;
    } catch {
      set({ messagesLoading: false });
    }
  },

  // Add a new message
  addMessage: (message) => {
    const chatId = message.chat?._id || message.chat;
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), message],
      },
      chats: state.chats.map((c) =>
        c._id === chatId
          ? { ...c, lastMessage: message, updatedAt: new Date().toISOString() }
          : c
      ).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)),
    }));

    // Increment unread if not active chat
    const { activeChat } = get();
    if (activeChat?._id !== chatId) {
      set((state) => ({
        unreadCounts: {
          ...state.unreadCounts,
          [chatId]: (state.unreadCounts[chatId] || 0) + 1,
        },
      }));
    }
  },

  // Update message (reactions, edits, etc.)
  updateMessage: (messageId, updates) => {
    set((state) => {
      const newMessages = { ...state.messages };
      Object.keys(newMessages).forEach((chatId) => {
        newMessages[chatId] = newMessages[chatId].map((m) =>
          m._id === messageId ? { ...m, ...updates } : m
        );
      });
      return { messages: newMessages };
    });
  },

  // Handle message deleted for everyone
  handleMessageDeleted: (messageId, chatId) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: (state.messages[chatId] || []).map((m) =>
          m._id === messageId
            ? { ...m, deletedForEveryone: true, content: '', attachments: [] }
            : m
        ),
      },
    }));
  },

  // Handle message unsent
  handleMessageUnsent: (messageId, chatId) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: (state.messages[chatId] || []).map((m) =>
          m._id === messageId
            ? { ...m, unsent: true, content: 'This message was removed', attachments: [] }
            : m
        ),
      },
    }));
  },

  // Typing indicators
  setTyping: (chatId, userId, userName, isTyping) => {
    set((state) => ({
      typingUsers: {
        ...state.typingUsers,
        [chatId]: {
          ...(state.typingUsers[chatId] || {}),
          [userId]: { userName, isTyping },
        },
      },
    }));
  },

  // Online users
  setUserStatus: (userId, status, lastSeen) => {
    set((state) => ({
      onlineUsers: {
        ...state.onlineUsers,
        [userId]: { status, lastSeen },
      },
    }));
  },

  // Add new chat to list
  addChat: (chat) => {
    set((state) => ({
      chats: [chat, ...state.chats.filter((c) => c._id !== chat._id)],
    }));
  },

  // Remove chat
  removeChat: (chatId) => {
    set((state) => ({
      chats: state.chats.filter((c) => c._id !== chatId),
      activeChat: state.activeChat?._id === chatId ? null : state.activeChat,
    }));
  },

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSearchQuery: (q) => set({ searchQuery: q }),

  // AI streaming message placeholder
  addStreamingMessage: (chatId, tempId) => {
    const placeholder = {
      _id: tempId,
      chat: chatId,
      sender: { _id: 'ai', name: 'Nexus AI', avatar: '' },
      content: '',
      type: 'ai',
      streaming: true,
      createdAt: new Date().toISOString(),
    };
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: [...(state.messages[chatId] || []), placeholder],
      },
    }));
  },

  appendStreamingContent: (chatId, tempId, text) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: (state.messages[chatId] || []).map((m) =>
          m._id === tempId ? { ...m, content: m.content + text } : m
        ),
      },
    }));
  },

  finalizeStreamingMessage: (chatId, tempId, realMessage) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: (state.messages[chatId] || []).map((m) =>
          m._id === tempId ? { ...realMessage, streaming: false } : m
        ),
      },
    }));
  },

  removeStreamingMessage: (chatId, tempId) => {
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: (state.messages[chatId] || []).filter((m) => m._id !== tempId),
      },
    }));
  },
}));
