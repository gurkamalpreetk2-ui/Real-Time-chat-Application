import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useUIStore = create(
  persist(
    (set) => ({
      theme: 'dark',
      modals: {
        deleteMessage: null,
        deleteChat: null,
        forwardMessage: null,
        userProfile: null,
        createGroup: false,
        settings: false,
        imageViewer: null,
      },
      replyTo: null,
      emojiPickerOpen: false,
      rightPanelOpen: false,

      setTheme: (theme) => {
        set({ theme });
        if (theme === 'dark') {
          document.documentElement.classList.add('dark');
          document.documentElement.classList.remove('light');
        } else {
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
        }
      },

      openModal: (name, data = true) =>
        set((state) => ({ modals: { ...state.modals, [name]: data } })),

      closeModal: (name) =>
        set((state) => ({ modals: { ...state.modals, [name]: null } })),

      setReplyTo: (message) => set({ replyTo: message }),
      clearReplyTo: () => set({ replyTo: null }),
      setEmojiPicker: (open) => set({ emojiPickerOpen: open }),
      toggleRightPanel: () => set((state) => ({ rightPanelOpen: !state.rightPanelOpen })),
    }),
    {
      name: 'nexus-ui',
      partialize: (state) => ({ theme: state.theme }),
    }
  )
);
