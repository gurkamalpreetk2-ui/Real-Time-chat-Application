import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Camera, Save, LogOut, Moon, Sun, Bell } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useUIStore } from '../store/uiStore';
import UserAvatar from '../components/ui/UserAvatar';
import api from '../services/api';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, updateUser, logout } = useAuthStore();
  const { theme, setTheme } = useUIStore();
  const [form, setForm] = useState({ name: user?.name || '', bio: user?.bio || '' });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data } = await api.put('/users/profile', form);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch { toast.error('Failed to save'); }
    setSaving(false);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const statusOptions = ['online', 'away', 'busy', 'offline'];
  const statusColors = { online: 'bg-emerald-500', away: 'bg-amber-500', busy: 'bg-red-500', offline: 'bg-slate-500' };

  const handleStatus = async (status) => {
    try {
      await api.put('/users/status', { status });
      updateUser({ status });
      toast.success(`Status set to ${status}`);
    } catch { toast.error('Failed to update status'); }
  };

  return (
    <div className="min-h-screen bg-nexus-bg p-4 md:p-8">
      <div className="fixed top-0 right-0 w-96 h-96 bg-nexus-accent/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-lg mx-auto relative z-10">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate('/')} className="btn-ghost p-2">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-display font-bold text-gradient">Profile</h1>
            <p className="text-nexus-muted text-sm">Manage your account</p>
          </div>
        </motion.div>

        {/* Avatar section */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="glass rounded-2xl p-6 mb-4 text-center">
          <div className="relative inline-block mb-4">
            <UserAvatar user={user} size="2xl" showStatus />
            <button className="absolute bottom-1 right-1 w-8 h-8 rounded-full bg-nexus-accent flex items-center justify-center shadow-nexus hover:bg-nexus-accent-light transition-colors">
              <Camera className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
          <h2 className="text-xl font-semibold">{user?.name}</h2>
          <p className="text-nexus-muted text-sm">{user?.email}</p>

          {/* Status selector */}
          <div className="flex justify-center gap-2 mt-4">
            {statusOptions.map((s) => (
              <button key={s} onClick={() => handleStatus(s)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border transition-all ${user?.status === s ? 'border-nexus-accent bg-nexus-accent/10 text-nexus-accent-light' : 'border-nexus-border text-nexus-muted hover:border-nexus-border/80'}`}>
                <div className={`w-2 h-2 rounded-full ${statusColors[s]}`} />
                <span className="capitalize">{s}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Edit form */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="glass rounded-2xl p-6 mb-4 space-y-4">
          <h3 className="font-medium text-sm text-nexus-muted uppercase tracking-wider">Edit Profile</h3>
          <div>
            <label className="text-xs text-nexus-muted block mb-1.5">Display name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-nexus w-full" />
          </div>
          <div>
            <label className="text-xs text-nexus-muted block mb-1.5">Bio</label>
            <textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })}
              rows={3} maxLength={200} placeholder="Tell people about yourself..."
              className="input-nexus w-full resize-none" />
            <p className="text-right text-[10px] text-nexus-muted mt-0.5">{form.bio.length}/200</p>
          </div>
          <button onClick={handleSave} disabled={saving} className="btn-nexus w-full flex items-center justify-center gap-2">
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-4 h-4" />}
            Save changes
          </button>
        </motion.div>

        {/* Preferences */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6 mb-4">
          <h3 className="font-medium text-sm text-nexus-muted uppercase tracking-wider mb-4">Preferences</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {theme === 'dark' ? <Moon className="w-4 h-4 text-nexus-muted" /> : <Sun className="w-4 h-4 text-nexus-muted" />}
                <span className="text-sm">Theme</span>
              </div>
              <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className={`w-11 h-6 rounded-full transition-colors relative ${theme === 'dark' ? 'bg-nexus-accent' : 'bg-nexus-border'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${theme === 'dark' ? 'left-6' : 'left-1'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="w-4 h-4 text-nexus-muted" />
                <span className="text-sm">Notifications</span>
              </div>
              <button
                onClick={async () => {
                  const { data } = await api.put('/users/profile', { notifications: !user?.notifications });
                  updateUser(data.user);
                }}
                className={`w-11 h-6 rounded-full transition-colors relative ${user?.notifications ? 'bg-nexus-accent' : 'bg-nexus-border'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${user?.notifications ? 'left-6' : 'left-1'}`} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Logout */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 p-3 rounded-2xl border border-nexus-error/30 text-nexus-error hover:bg-nexus-error/10 transition-colors text-sm font-medium">
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </motion.div>
      </div>
    </div>
  );
}
