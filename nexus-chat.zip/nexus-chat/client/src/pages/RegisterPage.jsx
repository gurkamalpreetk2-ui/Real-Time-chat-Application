import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, User, Eye, EyeOff, Zap } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [showPassword, setShowPassword] = useState(false);
  const { register, isLoading } = useAuthStore();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) return toast.error('Please fill all fields');
    if (form.password !== form.confirm) return toast.error('Passwords do not match');
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');

    const result = await register(form.name, form.email, form.password);
    if (result.success) {
      toast.success('Account created! Welcome 🎉');
      navigate('/');
    } else {
      toast.error(result.error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-nexus-bg">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-nexus-accent/10 rounded-full blur-3xl animate-pulse-soft" />
        <div className="absolute bottom-1/3 left-1/4 w-80 h-80 bg-cyan-500/8 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: '0.7s' }} />
      </div>
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'linear-gradient(#7c3aed 1px, transparent 1px), linear-gradient(90deg, #7c3aed 1px, transparent 1px)',
        backgroundSize: '50px 50px'
      }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md px-6"
      >
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-nexus-accent/20 border border-nexus-accent/30 mb-4 glow-accent">
            <Zap className="w-8 h-8 text-nexus-accent-light" />
          </div>
          <h1 className="text-3xl font-display font-bold text-gradient">Nexus Chat</h1>
          <p className="text-nexus-muted mt-1 text-sm">Join the future of messaging</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass rounded-2xl p-8">
          <h2 className="text-xl font-semibold mb-1">Create account</h2>
          <p className="text-nexus-muted text-sm mb-6">Start your journey today</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { name: 'name', label: 'Full name', icon: User, type: 'text', placeholder: 'John Doe' },
              { name: 'email', label: 'Email', icon: Mail, type: 'email', placeholder: 'you@example.com' },
            ].map(({ name, label, icon: Icon, type, placeholder }) => (
              <div key={name}>
                <label className="text-sm text-nexus-muted mb-1.5 block">{label}</label>
                <div className="relative">
                  <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-muted" />
                  <input
                    type={type}
                    name={name}
                    value={form[name]}
                    onChange={handleChange}
                    placeholder={placeholder}
                    className="input-nexus w-full pl-10"
                  />
                </div>
              </div>
            ))}

            <div>
              <label className="text-sm text-nexus-muted mb-1.5 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-muted" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="Min. 6 characters"
                  className="input-nexus w-full pl-10 pr-10"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-muted hover:text-nexus-text transition-colors">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="text-sm text-nexus-muted mb-1.5 block">Confirm password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-nexus-muted" />
                <input
                  type="password"
                  name="confirm"
                  value={form.confirm}
                  onChange={handleChange}
                  placeholder="••••••••"
                  className="input-nexus w-full pl-10"
                />
              </div>
            </div>

            <button type="submit" disabled={isLoading} className="btn-nexus w-full flex items-center justify-center gap-2 py-3 mt-2">
              {isLoading ? (
                <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /><span>Creating...</span></>
              ) : 'Create account'}
            </button>
          </form>

          <p className="text-center text-nexus-muted text-sm mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-nexus-accent-light hover:text-nexus-accent transition-colors font-medium">Sign in</Link>
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
