import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, MessageSquare, Users, Wifi, Bot, TrendingUp, Activity } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, Cell
} from 'recharts';
import api from '../services/api';

function StatCard({ icon: Icon, label, value, sub, colorClass = 'text-purple-400 bg-purple-500/10 border-purple-500/20', delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="glass rounded-2xl p-5"
    >
      <div className={`inline-flex p-2.5 rounded-xl border mb-3 ${colorClass}`}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-display font-bold mb-0.5">
        {typeof value === 'number' ? value.toLocaleString() : value}
      </p>
      <p className="text-sm text-nexus-muted">{label}</p>
      {sub && <p className="text-xs text-nexus-muted/60 mt-1">{sub}</p>}
    </motion.div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass rounded-xl px-3 py-2 text-xs shadow-nexus">
      <p className="text-nexus-muted mb-0.5">{label}</p>
      <p className="font-semibold text-nexus-text">{payload[0].value.toLocaleString()} messages</p>
    </div>
  );
};

const STAT_CARDS = (s) => [
  { icon: MessageSquare, label: 'Total messages',  value: s.totalMessages,    colorClass: 'text-purple-400 bg-purple-500/10 border-purple-500/20',  delay: 0    },
  { icon: Users,         label: 'Total users',     value: s.totalUsers,       colorClass: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',          delay: 0.05 },
  { icon: Wifi,          label: 'Online now',       value: s.onlineUsers,      colorClass: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20', delay: 0.1  },
  { icon: Bot,           label: 'AI messages',      value: s.aiMessages,       colorClass: 'text-amber-400 bg-amber-500/10 border-amber-500/20',       delay: 0.15 },
  { icon: TrendingUp,    label: 'AI usage',         value: `${s.aiUsagePercent}%`, sub: 'of all messages', colorClass: 'text-rose-400 bg-rose-500/10 border-rose-500/20', delay: 0.2 },
  { icon: Activity,      label: 'Total chats',      value: s.totalChats,       colorClass: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',    delay: 0.25 },
];

export default function DashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(({ data }) => {
        setStats(data.stats);
        setActivity(data.dailyActivity || []);
      })
      .catch(() => setError('Failed to load dashboard data'))
      .finally(() => setLoading(false));
  }, []);

  const maxCount = Math.max(...activity.map((d) => d.count), 1);

  return (
    <div className="min-h-screen bg-nexus-bg p-4 md:p-8 overflow-y-auto">
      <div className="fixed top-0 right-1/4 w-96 h-96 bg-nexus-accent/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate('/')} className="btn-ghost p-2">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-display font-bold text-gradient">Dashboard</h1>
            <p className="text-nexus-muted text-sm">Platform analytics &amp; insights</p>
          </div>
        </motion.div>

        {error && (
          <div className="glass rounded-2xl p-4 mb-6 border border-nexus-error/30 text-nexus-error text-sm">
            {error}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="glass rounded-2xl p-5 h-28 skeleton" />
            ))}
          </div>
        ) : stats ? (
          <>
            {/* Stat cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
              {STAT_CARDS(stats).map(({ icon, label, value, sub, colorClass, delay }) => (
                <StatCard key={label} icon={icon} label={label} value={value} sub={sub} colorClass={colorClass} delay={delay} />
              ))}
            </div>

            {/* Activity chart */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="glass rounded-2xl p-6"
            >
              <h3 className="font-semibold mb-0.5">Message activity</h3>
              <p className="text-xs text-nexus-muted mb-6">Last 7 days</p>
              {activity.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={activity} barCategoryGap="35%">
                    <XAxis
                      dataKey="label"
                      tick={{ fill: '#64748b', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: '#64748b', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(124,58,237,0.08)', radius: 6 }} />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {activity.map((entry, i) => (
                        <Cell key={i} fill={entry.count === maxCount ? '#7c3aed' : '#1e1e2e'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-48 flex items-center justify-center text-nexus-muted text-sm">
                  No activity data yet
                </div>
              )}
            </motion.div>
          </>
        ) : null}
      </div>
    </div>
  );
}
