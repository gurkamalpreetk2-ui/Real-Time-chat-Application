import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { useChatStore } from '../store/chatStore';
import { useUIStore } from '../store/uiStore';
import Sidebar from '../components/layout/Sidebar';
import ChatWindow from '../components/chat/ChatWindow';
import EmptyState from '../components/chat/EmptyState';
import DeleteMessageModal from '../components/modals/DeleteMessageModal';
import DeleteChatModal from '../components/modals/DeleteChatModal';
import ForwardMessageModal from '../components/modals/ForwardMessageModal';
import UserProfileModal from '../components/modals/UserProfileModal';
import CreateGroupModal from '../components/modals/CreateGroupModal';
import SettingsModal from '../components/modals/SettingsModal';

export default function ChatPage() {
  const { chatId } = useParams();
  const navigate = useNavigate();
  const { activeChat, fetchChats, setActiveChat, chats, loading } = useChatStore();
  const { modals } = useUIStore();
  const [mobileView, setMobileView] = useState('sidebar'); // 'sidebar' | 'chat'

  // Load chats once
  useEffect(() => {
    fetchChats();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // If URL has chatId, activate it once chats load
  useEffect(() => {
    if (chatId && chats.length > 0 && !activeChat) {
      const found = chats.find((c) => c._id === chatId);
      if (found) {
        setActiveChat(found);
        setMobileView('chat');
      }
    }
  }, [chatId, chats.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChatSelect = () => setMobileView('chat');
  const handleBack = () => setMobileView('sidebar');

  return (
    <div className="h-screen flex overflow-hidden bg-nexus-bg">
      {/* ── Sidebar ────────────────────────────────────────── */}
      <div className={`
        flex-col border-r border-nexus-border
        w-full md:w-80 lg:w-96 flex-shrink-0
        ${mobileView === 'sidebar' ? 'flex' : 'hidden md:flex'}
      `}>
        <Sidebar onChatSelect={handleChatSelect} />
      </div>

      {/* ── Chat window ────────────────────────────────────── */}
      <div className={`
        flex-1 flex flex-col min-w-0
        ${mobileView === 'chat' ? 'flex' : 'hidden md:flex'}
      `}>
        {loading && !activeChat ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="w-8 h-8 border-2 border-nexus-border border-t-nexus-accent rounded-full animate-spin" />
          </div>
        ) : activeChat ? (
          <ChatWindow onBack={handleBack} />
        ) : (
          <EmptyState />
        )}
      </div>

      {/* ── Modals ─────────────────────────────────────────── */}
      <AnimatePresence>
        {modals.deleteMessage && <DeleteMessageModal key="del-msg" />}
        {modals.deleteChat && <DeleteChatModal key="del-chat" />}
        {modals.forwardMessage && <ForwardMessageModal key="fwd-msg" />}
        {modals.userProfile && <UserProfileModal key="user-profile" />}
        {modals.createGroup && <CreateGroupModal key="create-group" />}
        {modals.settings && <SettingsModal key="settings" />}
      </AnimatePresence>
    </div>
  );
}
