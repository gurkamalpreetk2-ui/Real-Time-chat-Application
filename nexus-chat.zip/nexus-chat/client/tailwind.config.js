/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        nexus: {
          bg: '#0a0a0f',
          surface: '#111118',
          card: '#16161f',
          border: '#1e1e2e',
          accent: '#7c3aed',
          'accent-light': '#8b5cf6',
          'accent-glow': '#7c3aed33',
          text: '#e2e8f0',
          muted: '#64748b',
          success: '#10b981',
          warning: '#f59e0b',
          error: '#ef4444',
          online: '#10b981',
          away: '#f59e0b',
          busy: '#ef4444',
          offline: '#64748b',
        },
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        display: ['Syne', 'sans-serif'],
      },
      backgroundImage: {
        'nexus-gradient': 'linear-gradient(135deg, #7c3aed22 0%, #3b0764 100%)',
        'nexus-mesh': 'radial-gradient(at 40% 20%, #7c3aed20 0px, transparent 50%), radial-gradient(at 80% 0%, #4f46e520 0px, transparent 50%)',
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'slide-in-right': 'slideInRight 0.3s ease-out',
        'pulse-soft': 'pulseSoft 2s infinite',
        'typing': 'typing 1.4s infinite',
        'message-in': 'messageIn 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)',
        'shimmer': 'shimmer 1.5s infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: 'translateY(16px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        slideInRight: { from: { opacity: 0, transform: 'translateX(20px)' }, to: { opacity: 1, transform: 'translateX(0)' } },
        pulseSoft: { '0%, 100%': { opacity: 1 }, '50%': { opacity: 0.6 } },
        typing: {
          '0%, 60%, 100%': { transform: 'translateY(0)' },
          '30%': { transform: 'translateY(-6px)' },
        },
        messageIn: { from: { opacity: 0, transform: 'scale(0.95) translateY(4px)' }, to: { opacity: 1, transform: 'scale(1) translateY(0)' } },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      boxShadow: {
        'nexus': '0 0 0 1px #7c3aed33, 0 4px 32px #7c3aed20',
        'nexus-lg': '0 0 0 1px #7c3aed44, 0 8px 64px #7c3aed30',
        'message': '0 2px 8px rgba(0,0,0,0.3)',
      },
    },
  },
  plugins: [],
};
